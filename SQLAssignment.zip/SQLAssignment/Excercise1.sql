USE AdventureWorks2008R2

--1. Display the number of records in the [SalesPerson] table

SELECT COUNT(*) FROM Sales.SalesPerson;

--2. Select both the FirstName and LastName of records from the Person table where the FirstName begins with the letter �B�. 
--(Schema(s) involved: Person)

SELECT FirstName,LastName FROM Person.Person WHERE FirstName LIKE 'B%';

--3. Select a list of FirstName and LastName for employees where Title is one of Design Engineer, 
--Tool Designer or Marketing Assistant. (Schema(s) involved: HumanResources, Person)

SELECT p.FirstName,p.LastName,h.JobTitle FROM Person.Person p Inner Join HumanResources.Employee h 
On p.BusinessEntityID=h.BusinessEntityID WHERE h.JobTitle IN ('Design Engineer','Tool Designer','Marketing Specialist');

--4. Display the Name and Color of the Product with the maximum weight. (Schema(s) involved: Production)

SELECT TOP 1 Name,Color,Weight FROM Production.Product ORDER BY Weight DESC;

--5. Display Description and MaxQty fields from the SpecialOffer table. Some of the MaxQty values are NULL, 
--in this case display the value 0.00 instead.(Schema(s)involved: Sales)

SELECT Description,ISNULL(MaxQty,0) AS 'MaxQty' FROM Sales.SpecialOffer;

--6. Display the overall Average of the [CurrencyRate].[AverageRate] values for the exchange rate �USD� to �GBP� for the year 
--2005 i.e. FromCurrencyCode = �USD� and ToCurrencyCode = �GBP�. 
--Note: The field [CurrencyRate].[AverageRate] is defined as 'Average exchange rate for the day.' (Schema(s) involved: Sales)

SELECT AVG(AverageRate) AS 'Average Exchange Rate For The Day (YEAR 2005)' FROM Sales.CurrencyRate
WHERE FromCurrencyCode = 'USD' AND ToCurrencyCode = 'GBP' AND YEAR(CurrencyRateDate)=2005;

--7. Display the FirstName and LastName of records from the Person table where FirstName contains the letters �ss�. 
--Display an additional column with sequential numbers for each row returned beginning at integer (Schema(s) involved:Person)
SELECT ROW_NUMBER() OVER( ORDER BY FirstName) AS RowNumber,FirstName,LastName FROM Person.Person 
WHERE FirstName Like '%ss%';

--8.	Sales people receive various commission rates that belong to 1 of 4 bands. (Schema(s) involved: Sales)
--CommissionPct	Commission Band
--    0.00	         Band 0
--    Up To 1%	     Band 1
--    Up To 1.5%	 Band 2
--    Greater 1.5%	 Band 3

--Display the [SalesPersonID] with an additional column entitled �Commission Band� indicating the appropriate band as above.

SELECT BusinessEntityID AS 'SalesPersonID',CommissionPct, 
CASE WHEN CommissionPct = 0 THEN 'Band 0'
	WHEN CommissionPct<1  THEN 'Band 1'
	WHEN CommissionPct<1.5 THEN 'Band 2'
	ELSE 'Band 3'
END AS 'Commission Band' 
FROM Sales.SalesPerson;

--9. Display the managerial hierarchy from Ruth Ellerbrock (person type � EM) up to CEO Ken Sanchez. 
--Hint: use [uspGetEmployeeManagers] (Schema(s) involved: [Person], [HumanResources]) 

DECLARE @BusinessID int;
SELECT @BusinessID=BusinessEntityID FROM Person.Person WHERE FirstName='Ruth' 
AND LastName='Ellerbrock'
AND PersonType='EM';
EXEC uspGetEmployeeManagers @BusinessEntityID=@BusinessID;

--10.	Display the ProductId of the product with the largest stock level. 
--Hint: Use the Scalar-valued function [dbo]. [UfnGetStock]. (Schema(s) involved: Production)

SELECT ProductID,dbo.ufnGetStock(ProductID) AS 'Stock Level'
FROM Production.Product
WHERE dbo.ufnGetStock(ProductID) IN (SELECT MAX(dbo.ufnGetStock(ProductID))
FROM Production.Product);