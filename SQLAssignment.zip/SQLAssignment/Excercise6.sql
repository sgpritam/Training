--EXERCISE 6

--Write a trigger for the Product table to ensure the list price can never be raised more than 15 Percent in a single change. 
--Modify the above trigger to execute its check code only if the ListPrice column is updated (Use AdventureWorks Database).


USE AdventureWorks2008R2;

GO
CREATE TRIGGER xgProductListPriceChange
on Production.Product
FOR UPDATE
AS
IF EXISTS
    (SELECT 'True'
    FROM Inserted i
    JOIN Deleted d
            ON i.ProductID= d.ProductID
            WHERE abs(i.ListPrice-d.ListPrice)>=0.15*d.ListPrice
    )BEGIN
    RAISERROR('The list price can never be raised more than 15 Percent in a single change.',16,1)
            ROLLBACK TRAN
    END
GO


--Trigger executed as List Price value passed = 5 (Greater than 15% change hence value not updated and trigger executed)
SELECT * FROM Production.Product WHERE ProductID=1;

UPDATE Production.Product
SET ListPrice=5 WHERE ProductID=1;  

--Trigger not executed as List Price value passed = 1430(Less than 15% change hence value updated and trigger not executed)
SELECT * FROM Production.Product WHERE ProductID=680;
UPDATE Production.Product 
SET ListPrice=1430 WHERE ProductID=680;
SELECT * FROM Production.Product WHERE ProductID=680;


