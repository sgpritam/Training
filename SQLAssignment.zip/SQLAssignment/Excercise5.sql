/*
Write a Procedure supplying name information from the Person.
Person table and accepting a filter for the first name. 
Alter the above Store Procedure to supply Default Values if user does not enter any value.
( Use AdventureWorks)
*/

--CONNECT TO DATABASE
USE AdventureWorks2008R2;

--Function

GO
CREATE PROCEDURE Person.xFirstNameFilter
@Name VARCHAR(30)
AS 
SELECT * FROM Person.Person WHERE FirstName=@Name;
GO


ALTER PROCEDURE Person.xFirstNameFilter
@Name varchar(30)=NULL
AS
IF
@Name IS NULL
BEGIN;
  SET @Name='Ken'
END;
SELECT * FROM Person.Person WHERE FirstName=@Name;


EXEC Person.xFirstNameFilter;                 --Default value Ken
EXEC Person.xFirstNameFilter @Name='Terri';  --Passing user value
 