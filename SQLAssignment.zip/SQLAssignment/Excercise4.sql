/*
Create a function that takes as inputs a 
SalesOrderID, 
a Currency Code, 
and a date, 
and returns a table of all the SalesOrderDetail rows for that Sales Order including 
Quantity, ProductID, UnitPrice, and the unit price converted to the target currency based on the end of day rate for the date provided. 
Exchange rates can be found in the Sales.CurrencyRate table. 
( Use AdventureWorks)
*/

--CONNECT TO DATABASE;
USE AdventureWorks2008R2;
--Function
GO
CREATE FUNCTION Sales.NwUnitPrice(@SalesOrderID int,@CurrencyCode varchar(10),@Date date)
RETURNS TABLE 
AS RETURN
(SELECT SalesOrderID,ProductID, OrderQty,UnitPrice,
 UnitPrice*(SELECT EndOfDayRate FROM Sales.CurrencyRate 
			WHERE ToCurrencyCode = @CurrencyCode AND CurrencyRateDate = @Date) AS 'Price (Unit Price*End Of Day Rate)'
			FROM Sales.SalesOrderDetail where SalesOrderID = @SalesOrderID)
GO

Select * from Sales.NewUnitPrice(43659,'USD','2005-07-01');