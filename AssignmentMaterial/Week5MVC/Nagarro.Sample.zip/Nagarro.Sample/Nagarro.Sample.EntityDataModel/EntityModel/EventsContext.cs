﻿using System.Data.Entity;

namespace Nagarro.Sample.EntityDataModel
{
    public class EventsContext : DbContext
    {
        public EventsContext():base("EventsEntities")
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Sample> Samples { get; set; }
    }
}
