﻿namespace Nagarro.Sample.EntityDataModel
{
    public class Sample
    {
        public int Id { get; set; }
        public int SampleProperty1 { get; set; }
        public string SampleProperty3 { get; set; }
    }
}
