﻿using Nagarro.Sample.Shared;

namespace Nagarro.Sample.Console
{
    class Program
    {
        static void Main(string[] args)
        {
            SampleDTO sampleDTO = new SampleDTO();
            sampleDTO.SampleProperty1 = 22;
            sampleDTO.SampleProperty2 = "Robert";

            ISampleFacade sampleFacade = (ISampleFacade)FacadeFactory.Instance.Create(FacadeType.SampleFacade);
            OperationResult<SampleDTO> result = sampleFacade.SampleMethod(sampleDTO);
            if (result.IsValid())
            {
                var resultData = result.Data;
                System.Console.WriteLine("I am done with my work!");
            }
            System.Console.ReadLine();
        }
    }
}
