﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Nagarro.Sample.Shared;
using System;

namespace Nagarro.Sample.Business.Tests
{
    [TestClass]
    public class SampleBDCTest
    {
        private readonly ISampleBDC sampleBDC;
        private readonly Mock<IDACFactory> mockDacFactory;
        private readonly Mock<ISampleDAC> mockSampleDac;

        public SampleBDCTest()
        {
            mockDacFactory = new Mock<IDACFactory>();
            mockSampleDac = new Mock<ISampleDAC>();
            mockDacFactory.Setup(x => x.Create(It.IsAny<DACType>())).Returns(mockSampleDac.Object);
            sampleBDC = new SampleBDC(mockDacFactory.Object);
        }

        [TestMethod]
        public void SampleTests1()
        {
            mockSampleDac.Setup(x => x.SampleMethod(It.IsAny<SampleDTO>())).Returns(sampleDTO);
            var response = sampleBDC.SampleMethod(sampleDTO);
            Assert.AreEqual(OperationResultType.Success, response.ResultType);
        }

        [TestMethod]
        public void SampleTests2()
        {
            mockSampleDac.Setup(x => x.SampleMethod(It.IsAny<SampleDTO>())).Returns(sampleDTO);
            var response = sampleBDC.SampleMethod(new SampleDTO());
            Assert.AreEqual(OperationResultType.Failure, response.ResultType);
        }

        private SampleDTO sampleDTO = new SampleDTO
        {
            SampleProperty1 = 15,
            SampleProperty2 = "abc"
        };
    }
}
