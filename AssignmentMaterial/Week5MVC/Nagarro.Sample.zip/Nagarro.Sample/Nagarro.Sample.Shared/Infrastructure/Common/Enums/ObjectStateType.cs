﻿namespace Nagarro.Sample.Shared
{
    /// <summary>
    /// 
    /// </summary>
    public enum ObjectStateType
    {
        /// <summary>
        /// 
        /// </summary>
        None = 0,
        /// <summary>
        /// 
        /// </summary>
        Added = 1,
        /// <summary>
        /// 
        /// </summary>
        Updated = 2,
        /// <summary>
        /// 
        /// </summary>
        Deleted = 3
    }
}
