﻿using Nagarro.Sample.EntityDataModel;
using Nagarro.Sample.Shared;
using System;

namespace Nagarro.Sample.Data
{
    /// <summary>
    /// 
    /// </summary>
    public class SampleDAC : DACBase, ISampleDAC
    {
        #region Constructors
        /// <summary>
        /// 
        /// </summary>
        public SampleDAC()
            : base(DACType.SampleDAC)
        {

        }
        #endregion

        #region Public Methods
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sampleDTO"></param>
        /// <returns></returns>
        public SampleDTO SampleMethod(SampleDTO sampleDTO)
        {
            SampleDTO retVal = null;
            try
            {
                using(EventsContext dbContext = new EventsContext())
                {
                    EntityDataModel.Sample s = new EntityDataModel.Sample();
                    EntityConverter.FillEntityFromDTO(sampleDTO, s);

                    dbContext.Samples.Add(s);
                    dbContext.SaveChanges();

                    s.SampleProperty3 = "test";

                    EntityConverter.FillDTOFromEntity(s, sampleDTO);
                    retVal = sampleDTO;
                }
            }
            catch(Exception ex)
            {
                ExceptionManager.HandleException(ex);
                throw new DACException(ex.Message, ex);
            }

            return retVal;
        }
#endregion

    }
}
