﻿using FluentValidation;
using Nagarro.Sample.Shared;

namespace Nagarro.Sample.Validations
{
    public class SampleValidator : AbstractValidator<SampleDTO>
    {
        public SampleValidator()
        {
            //SampleProperty2 value should be not be null or empty
            RuleFor(dto => dto.SampleProperty2).NotNull().NotEmpty();

            //SampleProperty1 value should be greater than 10
            RuleFor(dto => dto.SampleProperty1).GreaterThan(10);
        }
    }

}
