﻿using Nagarro.Sample.Shared;
using Nagarro.Sample.Validations;
using System;

namespace Nagarro.Sample.Business
{
    /// <summary>
    /// 
    /// </summary>
    public class SampleBDC : BDCBase, ISampleBDC
    {
        private readonly IDACFactory dacFacotry;

        #region Constructor
        /// <summary>
        /// 
        /// </summary>
        public SampleBDC()
            : base(BDCType.SampleBDC)
        {
            dacFacotry = DACFactory.Instance;
        }

        public SampleBDC(IDACFactory dacFacotry)
            : base(BDCType.SampleBDC)
        {
            this.dacFacotry = dacFacotry;
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sampleDTO"></param>
        /// <returns></returns>
        public OperationResult<SampleDTO> SampleMethod(SampleDTO sampleDTO)
        {
            OperationResult<SampleDTO> retVal = null;
            try
            {
                NagarroSampleValidationResult validationResult = Validator<SampleValidator, SampleDTO>.Validate(sampleDTO);
                if (validationResult.IsValid)
                {
                    ISampleDAC sampleDAC = (ISampleDAC)dacFacotry.Create(DACType.SampleDAC);
                    SampleDTO resultDTO = sampleDAC.SampleMethod(sampleDTO);
                    if (resultDTO != null)
                    {
                        retVal = OperationResult<SampleDTO>.CreateSuccessResult(resultDTO);
                    }
                    else
                    {
                        retVal = OperationResult<SampleDTO>.CreateFailureResult("Failed!");
                    }
                }
                else
                {
                    retVal = OperationResult<SampleDTO>.CreateFailureResult(validationResult);
                }
            }
            catch (DACException dacEx)
            {
                retVal = OperationResult<SampleDTO>.CreateErrorResult(dacEx.Message, dacEx.StackTrace);
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex);
                retVal = OperationResult<SampleDTO>.CreateErrorResult(ex.Message, ex.StackTrace);
            }

            return retVal;
        }
        #endregion

        #region Private Methods
        #endregion
    }
}
