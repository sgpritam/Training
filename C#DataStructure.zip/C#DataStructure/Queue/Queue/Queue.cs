﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Queue
{
    class MyQueue
    {

        private object[] q;
        private int front;
        private int rear;
        private int capacity;



        public MyQueue(int size)
        {
            q = new object[size];
            front = 0;
            rear = -1;
            capacity = size;

        }

        public void Enqueue(object item)
        {
            if (rear == capacity - 1)
            {
                return;
            }
            else
            {
                Console.WriteLine("Enqueing {0}", item);
                q[++rear] = item;
            }
        }

        public object Dequeue()
        {
            if (front == rear + 1)
            {
                return -1;
            }
            else
            {

                return q[front++];
            }
        }
        public void DisplayQueue()
        {
            if (front == rear + 1)
            {

                throw new EmptyQueueException("Queue is Empty");
            }
            else
            {
                for (int i = front; i <= rear; i++)
                {
                    Console.Write(q[i] + " ");
                }
                Console.WriteLine();
            }
        }

        public int Size()
        {
            if (front == rear + 1)
            {

                throw new EmptyQueueException("Queue is Empty");
            }

            return rear - front + 1;
        }

        public void Reverse()
        {
            int size = Size();
            if (size == 0)
            {
                throw new EmptyQueueException("Queue is Empty");
            }
            Console.WriteLine("Reversed Queue: ");
            int start = 0;
            int end = size - 1;
            while (start < end)
            {
                var temp = q[start];
                q[start] = q[end];
                q[end] = temp;

                start = start + 1;
                end = end - 1;
            }
            for (int k = 0; k < size; k++)
            {
                Console.WriteLine(q[k]);
            }
        }

        public object Peek()
        {
            int size = Size();
            if (size == 0)
            {
                throw new EmptyQueueException("Queue is Empty");
            }
            return q[0];
        }


        public bool Contains(object data)
        {
            foreach (object i in q)
            {
                if (Convert.ToString(i) == Convert.ToString(data))
                    return true;
            }
            return false;
        }

        public void Iterator()
        {
            int size = Size();
            if (size == 0)
            {
                throw new EmptyQueueException("Queue is Empty");
            }
            Console.WriteLine("Iterating through the elements of the Queue ");
            foreach (object i in q)
            {
                Console.WriteLine(i);
            }
        }
    }
}
public class EmptyQueueException : Exception
{
    public EmptyQueueException(string message) : base(message) { }
}


