﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Queue
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {

                int i, n, choice;
                object data;

                Console.WriteLine("Enter the number of elements you want to Enqueue in queue : ");
                n = Convert.ToInt32(Console.ReadLine());
                MyQueue q1 = new MyQueue(n);
                for (i = 0; i < n; i++)
                {
                    Console.WriteLine("Enter the element");
                    data = Console.ReadLine();
                    q1.Enqueue(data);

                }
                while (true)
                {
                    Console.WriteLine("List of operations you can perform");
                    Console.WriteLine("1.Dequeue");
                    Console.WriteLine("2.Peek");
                    Console.WriteLine("3.Contains");
                    Console.WriteLine("4.Print the size of queue");
                    Console.WriteLine("5.Reverse the queue");
                    Console.WriteLine("6.Display the queue");
                    Console.WriteLine("7.Iterate the queue");

                    Console.WriteLine("8.Quit");

                    Console.Write("Enter your choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());


                    if (choice == 8)
                        break;
                    switch (choice)
                    {
                        case 1:
                            q1.Dequeue();
                            break;
                        case 2:
                            Console.WriteLine(q1.Peek());
                            break;
                        case 3:
                            Console.Write("Enter the element to be searched : ");
                            data = Console.ReadLine();
                            Console.WriteLine("Queue contains {0}: " + q1.Contains(data), data);
                            break;
                        case 4:
                            Console.WriteLine("Size of current queue: " + q1.Size());
                            break;
                        case 5:
                            q1.Reverse();
                            break;
                        case 6:
                            q1.DisplayQueue();
                            break;
                        case 7:
                            q1.Iterator();
                            break;
                        default:
                            Console.WriteLine("Wrong choice");
                            break;
                    }
                    Console.WriteLine();
                }
            }
            catch (EmptyQueueException e)

            {
                Console.WriteLine(e.Message);
            }
            Console.WriteLine("Press any key to exit");
            Console.ReadKey();

        }
    }



}

