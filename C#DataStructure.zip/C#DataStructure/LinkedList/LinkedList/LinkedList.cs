﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinkedList
{
    class LinkedList
    {
        private Node start;
        public LinkedList()
        {
            start = null;
        }
        public void DisplayList()
        {
            Node p;
            if(start == null)
            {
                Console.WriteLine("List is empty");
                return;
            }
            Console.WriteLine("List is : ");
            p = start;
            while (p != null)
            {
                Console.Write(p.data + " ");
                p = p.next;
            }
            Console.WriteLine();
        }
        public void CountNode()
        {
            int number = 0;
            Node p = start;
            while (p != null)
            {
                number++;
                p = p.next;
            }
            Console.Write("Number of nodes in the list = " + number);
        }
        public bool Search(int d)
        {
            int position = 1;
            Node p = start;
            while (p != null)
            {
                if (p.data == d)
                    break;
                position++;
                p = p.next;
            }
            if(p == null)
            {
                Console.WriteLine(d + " not found in list");
                return false;
            }
            else
            {
                Console.WriteLine(d + " is at position " + position);
                return true;
            }
        }

        public void InsertFront(int data)
        {
            Node temp = new Node(data);
            temp.next = start;
            start = temp;
        }

        public void InsertBack(int data)
        {
            Node p;
            Node temp = new Node(data);
            if (start == null)
            {
                start = temp;
                return;
            }
            p = start;
            while (p.next != null)
                p = p.next;
            p.next = temp;
        }

        public void CreateList()
        {
            int i, number, data;
            Console.WriteLine("Enter the number of node : ");
            number = Convert.ToInt32(Console.ReadLine());

            if (number == 0)
                return;
            for(i = 1; i <= number; i++)
            {
                Console.Write("Enter the element to be inserted : ");
                data = Convert.ToInt32(Console.ReadLine());
                InsertBack(data);
            }
        }
        public void InsertAtPosition(int data, int position)
        {
            Node temp;
            int i;
            if(position == 1)
            {
                temp = new Node(data);
                temp.next = start;
                start = temp;
                return;
            }
            Node p = start;
            for (i = 1; i < position - 1 && p != null; i++)
                p = p.next;
            if(p==null)
                Console.WriteLine("You can insert only upto "+ i + "th position");
            else
            {
                temp = new Node(data);
                temp.next = p.next;
                p.next = temp;
            }
        }

        public void DeleteFront()
        {
            if (start == null)
                return;
            start = start.next;
        }
        public void DeleteBack()
        {
            if (start == null)
                return;
            if(start.next == null)
            {
                start = null;
                return;
            }
            Node p = start;
            while (p.next.next != null)
                p = p.next;
            p.next = null;
        }
        public void DeleteNode(int d)
        {
            if (start == null)
            {
                Console.WriteLine("List is empty\n");
                return;
            }
            if (start.data == d)
            {
                start = start.next;
                return;
            }
            Node p = start;
            while (p.next != null)
            {
                if (p.next.data == d)
                    break;
                p = p.next;
            }
            if (p.next == null)
                Console.WriteLine("Element " + d + " not in list");
            else
                p.next = p.next.next;
        }

        public void ReverseList()
        {
            Node prev = null, current = start, next = null;
            while (current != null)
            {
                next = current.next;
                current.next = prev;
                prev = current;
                current = next;
            }
            start = prev;
        }

        public void Center()
        {
            Node SlowPtr = start;
            Node FastPtr = start;

            if (start != null)
            {
                while (FastPtr != null &&
                       FastPtr.next != null)
                {
                    FastPtr = FastPtr.next.next;
                    SlowPtr = SlowPtr.next;
                }
                Console.WriteLine("The middle element is [" + SlowPtr.data + "] \n");
            }
        }



    }
}
