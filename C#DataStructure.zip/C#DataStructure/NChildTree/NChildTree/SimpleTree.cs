﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NChildTree
{
    class SimpleTree
    {
        public Node root 
        { 
            get; 
            private set; 
        }
        public SimpleTree()
        {
            root = null;
        }
        public void Insert(int key)
        {
            root = InsertRec(root, key);
        }

        Node InsertRec(Node root, int key)
        {
            if(root == null)
            {
                root = new Node(key);
                return root;
            }
            if (key < root.key)
            {
                root.left = InsertRec(root.left, key);
            }
            else
            {
                root.right = InsertRec(root.right, key);
            }
            return root;
        }
        public void DeleteKey(int key)
        {
            root = DeleteRec(root, key);
        }
        Node DeleteRec(Node root, int key)
        {
            if (root == null)
            {
                return root;
            }
            if (key < root.key)
                root.left = DeleteRec(root.left, key);
            else if(key>root.key) 
                root.right = DeleteRec(root.right,key);
            else
            {
                if (root.left == null)
                    return root.right;
                else if (root.right == null)
                    return root.left;
                root.key = MinValue(root.right);
                root.right = DeleteRec(root.right, root.key);
            }
            return root;
        }
        int MinValue(Node root)
        {
            int minVal = root.key;
            while(root.left != null)
            {
                minVal = root.left.key;
                root = root.left;
            }
            return minVal;
        }
        public Boolean ContainsRec(int key)
        {
            return ContainsRec(key, root);
        }
        private bool ContainsRec(int key,Node root)
        {
            if (root == null)
                return false;
            int CompareResult = key.CompareTo(root.key);
            if (CompareResult < 0)
                return ContainsRec(key, root.left);
            else if (CompareResult > 0)
                return ContainsRec(key, root.right);
            else
                return true;
        }


        public void PrintGivenLevel(int level)
        {
            LevelOrderTraversal(root, level);
        }
        public void LevelOrderTraversal(Node root,int level)
        {
            if(root== null)
            {
                return;
            }
            if(level == 1)
                Console.WriteLine(root.key + " ");
            else if (level > 1)
            {
                LevelOrderTraversal(root.left, level - 1);
                LevelOrderTraversal(root.right, level - 1);
            }
        }
        public int TreeHeight(Node root)
        {
            if (root == null)
            {
                return 0;
            }
            else
            {
                int lheight = TreeHeight(root.left);
                int rheight = TreeHeight(root.right);
                if (lheight > rheight)
                {
                    return lheight + 1;
                }
                else
                {
                    return rheight + 1;
                }
            }
        }
    }
}
