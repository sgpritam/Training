﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NChildTree
{
    class Program
    {
        static void Main(string[] args)
        {
            SimpleTree SplTree = new SimpleTree();
            menu:
            Console.WriteLine("\n------------   MENU    -------------------");
            Console.WriteLine("1.Insert\n2.Delete\n3.Search an element\n4.Get Element By Level\n5.Iterator Breadth First\n6.Iterator Depth First\n7.Traverse/Print Breadth First\n8.Traverse/Print Depth First\n9.Quit");
            int choice = 0;
            if (int.TryParse(Console.ReadLine(), out choice))
            {
                switch (choice)
                {
                    case 1:
                        int data;
                        try
                        {
                            Console.WriteLine("Enter a value want to insert in this Tree : ");
                            data = int.Parse(Console.ReadLine());
                            SplTree.Insert(data);
                        }
                        catch (Exception)
                        {
                            Console.WriteLine("ERROR : Input error occured");
                        }
                        goto menu;
                    case 2:
                        try
                        {
                            Console.WriteLine("Enter the element to be deleted : ");
                            data = int.Parse(Console.ReadLine());
                            SplTree.DeleteKey(data);
                        }
                        catch (Exception)
                        {
                            Console.WriteLine("ERROR : Input error occured");
                        }
                        goto menu;
                    case 3:
                        try
                        {
                            Console.WriteLine("Enter the element to be searched : ");
                            data = int.Parse(Console.ReadLine());
                            if(SplTree.ContainsRec(data))
                                Console.WriteLine("Element Found");
                            else
                                Console.WriteLine("Element not found");
                        }
                        catch
                        {
                            Console.WriteLine("ERROR : Input error occured");
                        }
                        goto menu;
                    case 4:
                        try
                        {
                            Console.WriteLine("Enter the Tree level want to view the elements : ");
                            data = int.Parse(Console.ReadLine());
                            SplTree.PrintGivenLevel(data);
                        }
                        catch
                        {
                            Console.WriteLine("ERROR : Input error occured");
                        }
                        goto menu;
                    case 5:
                        Iterator BreadthFirst = new Iterator(SplTree.root);
                        BreadthFirst.PrintBreadthFirstIterator();
                        goto menu;
                    case 6:
                        Iterator DepthFirst = new Iterator(SplTree.root);
                        DepthFirst.PrintDepthFirstIterator();
                        goto menu;
                    case 7:
                        Traverse traverse = new Traverse(SplTree.root);
                    TraverseMenu:
                        int TraverseChoice = 0;
                        Console.WriteLine("\n------ Breadth First   -------\n1.Level Order Traversal");
                        Console.WriteLine("-------------    Depth First -------------\n2.InOrder\t3.PreOrder\t4.PostOrder\t5.Exit From Traversing");
                        if(int.TryParse(Console.ReadLine(),out TraverseChoice))
                        {
                            switch (TraverseChoice)
                            {
                                case 1:
                                    traverse.PrintLevelOrder();
                                    goto TraverseMenu;
                                case 2:
                                    traverse.Inorder();
                                    goto TraverseMenu;
                                case 3:
                                    traverse.Preorder();
                                    goto TraverseMenu;
                                case 4:
                                    traverse.PostOrder();
                                    goto TraverseMenu;
                                case 5:
                                    goto menu;
                                default:
                                    Console.WriteLine("ERROR : Please entera valid choice ");
                                    goto TraverseMenu;
                            }
                        }
                        else
                        {
                            Console.WriteLine("ERROR: Input error occured");
                            goto TraverseMenu;
                        }
                        //goto menu;
                    case 8:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("ERROR: ENTER A VALID CHOICE");
                        goto menu;
                }
            }
            else
            {
                Console.WriteLine("ERROR : Please entera valid choice ");
                goto menu;
            }

        }
    }
}
