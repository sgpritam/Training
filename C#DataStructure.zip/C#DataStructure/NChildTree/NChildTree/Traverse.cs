﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NChildTree
{
    class Traverse
    {
        Node root;
        public Traverse(Node root)
        {
            this.root = root;
        }
        public void PrintLevelOrder()
        {
            if (root == null)
            {
                Console.WriteLine("Tree is empty");
                return;
            }
            int h = TreeHeight(root);
            Console.WriteLine("\n");
            for(int i = 1; i <= h; i++)
            {
                LevelOrderTraversal(root, i);
            }
            
        }
        public void LevelOrderTraversal(Node root,int level)
        {
            if (root == null)
                return;
            if(level==1)
                Console.WriteLine(root.key + " ");
            else if (level > 1)
            {
                LevelOrderTraversal(root.left, level - 1);
                LevelOrderTraversal(root.right, level - 1);
            }
        }
        public void Inorder()
        {
            if (root == null)
            {
                Console.WriteLine("Tree is empty");
                return;
            }
            Console.WriteLine("\n#Tree : ");
            InorderRec(root);
        }
        void InorderRec(Node root)
        {
            if (root != null)
            {
                InorderRec(root.left);
                Console.WriteLine(root.key + " ");
                InorderRec(root.right);
            }
        }
        public void Preorder()
        {
            if (root == null)
            {
                Console.WriteLine("Tree is empty");
                return;
            }
            Console.WriteLine("\n#Tree : ");
            PreorderRec(root);
        }
        void PreorderRec(Node root)
        {
            if (root != null)
            {
                Console.WriteLine("root.key" + " ");
                PreorderRec(root.left);
                PreorderRec(root.right);
            }
        }
        public void PostOrder()
        {
            if (root == null)
            {
                Console.WriteLine("Tree is empty");
                return;
            }
            Console.WriteLine("\n#Tree : ");
            PostorderRec(root);
        }
        void PostorderRec(Node root)
        {
            if (root != null)
            {
                PostorderRec(root.left);
                PostorderRec(root.right);
                Console.WriteLine(root.key + " ");
            }
        }
        public int TreeHeight(Node root)
        {
            if (root == null)
                return 0;
            else
            {
                int lheight = TreeHeight(root.left);
                int rheight = TreeHeight(root.right);
                if (lheight > rheight)
                    return lheight + 1;
                else
                    return rheight + 1;
            }
        }
    }
}
