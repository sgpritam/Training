﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NChildTree
{
    class Iterator
    {
        Node root;
        List<int> BreadthFirstNodeElements;
        List<int> DepthFirstNodeElements;

        public Iterator(Node root)
        {
            this.root = root;
        }
        public IEnumerable<string> GetBreadthFirstArray()
        {
            LevelOrder();
            foreach(var items in BreadthFirstNodeElements)
            {
                yield return items.ToString();
            }
        }
        public void PrintBreadthFirstIterator()
        {
            IEnumerable<string> myitems = GetBreadthFirstArray();
            foreach(var i in myitems)
            {
                Console.WriteLine(i + " ");
            }
        }
        public void LevelOrder()
        {
            BreadthFirstNodeElements = new List<int>();
            if (root == null)
            {
                Console.WriteLine("Tree is empty!");
                return;
            }
            int h = TreeHeight(root);
            for(int i = 1; i <= h; i++)
            {
                AddBreadthFirstRecord(root, i);
            }
        }
        public void AddBreadthFirstRecord(Node root,int level)
        {
            if (root == null)
                return;
            if (level == 1)
                BreadthFirstNodeElements.Add(root.key);
            else if (level > 1)
            {
                AddBreadthFirstRecord(root.left, level - 1);
                AddBreadthFirstRecord(root.right, level - 1);
            }

        }
        public IEnumerable<string> GetDepthFirstArray()
        {
            Inorder();
            foreach(var items in DepthFirstNodeElements)
            {
                yield return items.ToString();
            }
        }
        public void PrintDepthFirstIterator()
        {
            IEnumerable<string> myitems = GetDepthFirstArray();
            foreach(var i in myitems)
            {
                Console.WriteLine(i+ " ");
            }
        }
        public void Inorder()
        {
            DepthFirstNodeElements = new List<int>();
            if (root == null)
            {
                Console.WriteLine("Tree is Empty");
                return;
            }
            AddInorderRecord(root);
        }
        void AddInorderRecord(Node root)
        {
            if (root != null)
            {
                AddInorderRecord(root.left);
                DepthFirstNodeElements.Add(root.key);
                AddInorderRecord(root.right);
            }
        }
        public int TreeHeight(Node root)
        {
            if (root == null)
                return 0;
            else
            {
                int lheight = TreeHeight(root.left);
                int rheight = TreeHeight(root.right);
                if (lheight > rheight)
                    return lheight + 1;
                else
                    return rheight + 1;
            }
        }
    }
}
