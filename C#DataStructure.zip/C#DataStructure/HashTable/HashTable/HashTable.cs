﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hashtable
{
    public class Hashtable
    {
        public struct Hash
        {
            public string value;
            public string key;
        }
        public List<Hash> ll = new List<Hash>();
        public void Insert(string v, string key)
        {
            Hash add = new Hash();
            add.value = v;
            add.key = key;
            ll.Add(add);
        }
        public void Remove(string k)
        {
            Hash remove = new Hash();
            foreach (var element in ll)
            {
                if (element.key == k)
                {
                    remove.key = element.key;
                    remove.value = element.value;
                }
            }
            ll.Remove(remove);
        }
        public void Contain(string v)
        {
            int c = 0;
            foreach (var element in ll)
            {
                if (element.value == v) c = 1;
            }
            if (c == 1) Console.WriteLine("The given element is present");
            else Console.WriteLine("The given element is not present");
        }
        public void Bykey(string k)
        {
            int c = 0;
            foreach (var element in ll)
            {
                if (element.key == k) Console.WriteLine(element.value);
                c++;
            }
            if (c == 0) Console.WriteLine("Not a valid key");
        }
        public void Size()
        {
            int c = 0;
            foreach (var element in ll)
            {
                c++;
            }
            Console.WriteLine(c);
        }
        public void Print()
        {
            foreach (var element in ll)
            {
                Console.WriteLine(element.value, element.key);
            }
        }
    }
}
