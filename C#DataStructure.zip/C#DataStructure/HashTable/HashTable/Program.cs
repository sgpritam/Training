﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hashtable
{
    class Program
    {
        static void Main(string[] args)
        {
            Hashtable obj = new Hashtable();
            Console.WriteLine("Enter 1 to continue program and 0 to exit");
            int op = int.Parse(Console.ReadLine());
            do
            {
                Console.WriteLine("Ënter 1 for Insert");
                Console.WriteLine("Ënter 2 for Remove");
                Console.WriteLine("Ënter 3 for Contains");
                Console.WriteLine("Ënter 4 for Value By Key");
                Console.WriteLine("Ënter 5 for Size");
                Console.WriteLine("Ënter 6 for Print");
                Console.WriteLine("Enter 7 to Exit");
                int ch = int.Parse(Console.ReadLine());
                if (ch == 1)
                {
                    Console.WriteLine("Enter value and key to add");
                    string v = Console.ReadLine();
                    string k = Console.ReadLine();
                    obj.Insert(v, k);

                }
                if (ch == 2)
                {
                    Console.WriteLine("Enter key to be deleted");
                    string k = Console.ReadLine();
                    obj.Remove(k);
                }
                if (ch == 3)
                {
                    Console.WriteLine("Enter value to check");
                    string check = Console.ReadLine();
                    obj.Contain(check);
                }
                if (ch == 4)
                {
                    Console.WriteLine("Enter key to receive value");
                    string k = Console.ReadLine();
                    obj.Bykey(k);
                }
                if (ch == 5)
                {
                    obj.Size();
                }
                if (ch == 6)
                {
                    obj.Print();
                }
                if (ch == 7)
                {
                    op = op - 1;
                }
                Console.WriteLine();
            } while (op != 0);
            if (op == 0)
            {
                Console.WriteLine("Thank you for using.");
            }
        }
    }
}
