﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stack
{
    class Program
    {
        static void Main(string[] args)
        {
            var Mystack = new Stacks<int>();
            string input1;
            int caseno;
            do
            {
                Console.WriteLine(Constants.wel);
                input1 = Console.ReadLine();
                caseno = Int32.Parse(input1);

                if(caseno == 9)
                {
                    break;
                }

                switch (caseno)
                {
                    case 1:
                        {
                            int data;
                            Console.WriteLine(Constants.Push);
                            input1 = Console.ReadLine();
                            data = Int32.Parse(input1);
                            Mystack.Push(data);
                            break;
                        }
                    case 2:
                        Mystack.Pop();
                        break;
                    case 3:
                        Mystack.Peek();
                        break;
                    case 4:
                        {
                            int data;
                            Console.WriteLine("Enter the element you want to find : ");
                            input1 = Console.ReadLine();
                            data = Int32.Parse(input1);
                            Mystack.Contains(data);
                            break;
                        }
                    case 5:
                        Mystack.Size();
                        break;
                    case 6:
                        Mystack.Reverse();
                        break;
                    case 7:
                        IEnumerable<string> ele = Mystack.Iterator();
                        foreach (var element in ele)
                        {
                            Console.WriteLine(element);
                        }
                        break;
                    case 8:
                        Mystack.Traverse();
                        break;

                    case 9:
                        Console.WriteLine("Exiting...");
                        break;

                    default:
                        Console.WriteLine("Wrong Input");
                        break;
                }
                Console.WriteLine(Constants.repeat);
                input1 = Console.ReadLine();
            } while (input1 == "Yes");
        }
    }
}