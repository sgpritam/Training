﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stack
{
    class Constants
    {
        public static string wel = "The operations that you can perform are" +
         "\n1.Push " +
         "\n2.Pop " +
         "\n3.Peek  " +
         "\n4.Contains " +
         "\n5.Size " +
         "\n6.Reverse " +
         "\n7.Iterator" +
         "\n8.Print " +  
        "\n9.Quit " + "\nEnter the operations you want to perform on Queue" ;

        public static string Push = "Enter the value you want to Push";
        public static string repeat = "Do you want to perform another operation ?\n Enter Yes\n No";
    }
}
