﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stack
{
    public class Node<Type>
    {
        public Node<Type> Next { get; set; }

        public Type Data { get; set; }
        public Node(Type data)
        {
            Data = data;
            Next = null;
        }
    }
    class Stacks<Type>
    {
        public Node<Type> Top;
        public Stacks()
        {
            this.Top = null;
        }
        public void Push(Type value)
        {
            Node<Type> newNode = new Node<Type>(value);
            if (Top == null)
            {
                newNode.Next = null;
            }
            else
            {
                newNode.Next = Top;
            }
            Top = newNode;
            Console.WriteLine("{0} pushed to stack", value);
        }
        public void Pop()
        {
            if (Top == null)
            {
                Console.WriteLine("Stack Underflow. Deletion not possible");
                return;
            }

            Console.WriteLine("Item popped is {0}", Top.Data);
            Top = Top.Next;
        }
        public void Peek()
        {
            if (Top == null)
            {
                Console.WriteLine("Stack Underflow.");
                return;
            }

            Console.WriteLine("{0} is on the top of Stack", this.Top.Data);
        }
        public void Size()
        {
            int length = 0;
            Node<Type> TempNode = this.Top;
            //calculate the size by reaching till the end of queue
            while (TempNode != null)
            {
                length++;
                TempNode = TempNode.Next;
            }
            Console.WriteLine( "The size of stack is " + length);
        }
        public bool Contains(Type data)
        {
            Node<Type> TempNode;
            TempNode = Top;
            while (TempNode != null)
            {
                //comparing input with data in linked list
                if (TempNode.Data.Equals(data))
                {
                    Console.WriteLine("Element " + data + " is found");
                    return true;
                    
                }
                TempNode = TempNode.Next;
            }
            return false;
           //Console.WriteLine("Element is not found");
        }
        //printing all the elements
        public void Traverse()
        {
            Node<Type> TempNode;
            TempNode = Top;
            while (TempNode != null)
            {
                Console.WriteLine("Element is {0} ", TempNode.Data);
                //Console.WriteLine(TempNode.data);
                TempNode = TempNode.Next;
                //Dequeue();
            }
        }
        public void Reverse()
        {
            Node<Type> NextNode = null;
            Node<Type> PreviousNode = null;
            Node<Type> TempNode = Top;
            Node<Type> AnotherTempNode = Top;
            //logic to reverse linked list
            while (TempNode != null)
            {
                NextNode = TempNode.Next;
                TempNode.Next = PreviousNode;
                PreviousNode = TempNode;
                TempNode = NextNode;
            }
            Top = PreviousNode;
            Traverse();

        }
        public IEnumerable<string> Iterator()
        {
            Node<Type> temp = Top;
            while (temp != null)
            {
                yield return " data is " + temp.Data.ToString();
                temp = temp.Next;
            }

        }
    }
}
