﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriorityQueue
{
    class PriorityQueueTest
    {
        static void Main(string[] args)
        {
            MyPriorityQueue p1 = new MyPriorityQueue();
            try
            {
                int i, n, choice;
                int data;

                Console.WriteLine("Enter the number of elements you want to Enqueue in Priority Queue");
                n = Convert.ToInt32(Console.ReadLine());

                for (i = 0; i < n; i++)
                {
                    Console.WriteLine("Enter the element");
                    data = Convert.ToInt32(Console.ReadLine());
                    p1.Enqueue(data);

                }

                while (true)
                {
                    Console.WriteLine("List of operations you can perform");
                    Console.WriteLine("1.Enqueue");
                    Console.WriteLine("2.Dequeue");
                    Console.WriteLine("3.Peek");
                    Console.WriteLine("4.Contains");
                    Console.WriteLine("5.Print the size of queue");
                    Console.WriteLine("6.Reverse the queue");
                    Console.WriteLine("7.Display the queue");
                    Console.WriteLine("8.Iterate the queue");

                    Console.WriteLine("9.Quit");

                    Console.Write("Enter your choice: ");
                    choice = Convert.ToInt32(Console.ReadLine());


                    if (choice == 9)
                        break;
                    switch (choice)
                    {
                        case 1:
                            Console.WriteLine("Enter the element");
                            data = Convert.ToInt32(Console.ReadLine());
                            p1.Enqueue(data);
                            break;
                        case 2:
                            p1.Dequeue();
                            break;
                        case 3:
                            Console.WriteLine(p1.Peek());
                            break;
                        case 4:
                            Console.Write("Enter the element to be searched : ");
                            data = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("queue contains {0}: " + p1.Contains(data), data);
                            break;
                        case 5:
                            Console.WriteLine("Size of current queue: " + p1.Size());
                            break;
                        case 6:
                            p1.Reverse();
                            break;
                        case 7:
                            p1.DisplayQueue();
                            break;
                        case 8:
                            p1.Iterator();
                            break;
                        default:
                            Console.WriteLine("Wrong choice");
                            break;
                    }
                    Console.WriteLine();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            Console.WriteLine("\nPress any key to exit");
            Console.ReadKey();
        }
    }
}
