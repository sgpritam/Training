﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriorityQueue
{
    class MyPriorityQueue
    {
        private readonly int[] priorityQueue = new int[20];
        int size = 0;

        public void Enqueue(int data)
        {
            Console.WriteLine("Enqueuing: " + data);
            priorityQueue[size + 1] = data;
            size++;
            SortingBottomToTop(size);
        }

        public void SortingBottomToTop(int index)
        {
            int parent = (index) / 2;

            if (index <= 1)
            {
                return;
            }

            if (priorityQueue[index] > priorityQueue[parent])
            {
                int temp = priorityQueue[index];
                priorityQueue[index] = priorityQueue[parent];
                priorityQueue[parent] = temp;
            }
            SortingBottomToTop(parent);
        }

        public void Dequeue()
        {
            if (size <= 0)
            {
                throw new EmptyPriorityQueueException("Priority Queue is Empty");
            }
            Console.WriteLine("Dequeuing: " + priorityQueue[1]);
            priorityQueue[1] = priorityQueue[size];
            size--;
            SortingTopToBottom(1);
        }

        public void SortingTopToBottom(int index)
        {
            int leftChild = (index * 2);
            int rightChild = (index * 2) + 1;
            int greatestChild = 0;

            if (size < leftChild)
            {
                return;
            }

            else if (size == leftChild)
            {
                if (priorityQueue[index] < priorityQueue[leftChild])
                {
                    int temp = priorityQueue[index];
                    priorityQueue[index] = priorityQueue[leftChild];
                    priorityQueue[leftChild] = temp;
                }
            }

            else
            {
                if (priorityQueue[leftChild] > priorityQueue[rightChild])
                {
                    greatestChild = leftChild;
                }
                else
                {
                    greatestChild = rightChild;
                }

                if (priorityQueue[index] < priorityQueue[greatestChild])
                {
                    int temp = priorityQueue[index];
                    priorityQueue[index] = priorityQueue[greatestChild];
                    priorityQueue[greatestChild] = temp;
                }
            }
            SortingTopToBottom(greatestChild);
        }

        public int Peek()
        {
            if (size <= 0)
            {
                throw new EmptyPriorityQueueException("Priority Queue is Empty");
            }
            return priorityQueue[1];
        }

        public bool Contains(int data)
        {
            foreach (int i in priorityQueue)
            {
                if (i == data)
                {
                    return true;
                }
            }
            return false;
        }

        public int Size()
        {
            return size;
        }

        public void Reverse()
        {
            if (size <= 0)
            {
                throw new EmptyPriorityQueueException("Priority Queue is Empty");
            }
            Console.WriteLine("\nReverse Priority Queue: ");
            int i = 1;
            int j = size;
            while (i < j)
            {
                var temp = priorityQueue[i];
                priorityQueue[i] = priorityQueue[j];
                priorityQueue[j] = temp;

                i += 1;
                j -= 1;
            }
            for (int k = 1; k <= size; k++)
            {
                Console.WriteLine(priorityQueue[k]);
            }
        }

        public void Iterator()
        {
            if (size <= 0)
            {
                throw new EmptyPriorityQueueException("Priority Queue is Empty");
            }
            Console.WriteLine("\nIterating through the elements of the Priority Queue: ");
            for (int i = 1; i <= size; i++)
            {
                Console.WriteLine(priorityQueue[i]);
            }
        }

        public void DisplayQueue()
        {
            if (size == 0)
            {
                throw new EmptyPriorityQueueException("Priority Queue is Empty");
            }
            Console.Write("\nCurrent items in the Priority Queue: ");
            for (int i = 1; i <= size; i++)
            {
                Console.Write(priorityQueue[i] + " ");
            }
            Console.WriteLine();
        }
    }
}
public class EmptyPriorityQueueException : Exception
{
    public EmptyPriorityQueueException(string message) : base(message) { }
}