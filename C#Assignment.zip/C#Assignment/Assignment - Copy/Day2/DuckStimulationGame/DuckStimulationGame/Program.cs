﻿using System;

namespace DuckStimulationGame
{
    class Program
    {
        static void Main(string[] args)
        {
            IDucks<Types> obj = new DuckStimulator();
            Types typeOfDuck = Types.Nothing;
            Console.WriteLine("----\t\tWelcome To Duck Stimulation Game\t\t----\n");
            Console.WriteLine("----\t\tWant To Create some Awesome Ducks ?\t\t----\n");
            Console.WriteLine("Please select the type of Duck you want to create ...");

            bool flag = true;
            int opt;
            while (flag)
            {
                Console.WriteLine("Choose -\n1. Rubber\n2. Mallard\n3. Redhead ");
                var temp = Convert.ToString(Console.ReadKey().KeyChar);
                if (int.TryParse(temp, out opt))
                {
                    switch (opt)
                    {
                        case 1:
                            flag = false;
                            typeOfDuck = (Types)0;
                            break;
                        case 2:
                            flag = false;
                            typeOfDuck = (Types)1;
                            break;
                        case 3:
                            flag = false;
                            typeOfDuck = (Types)2;
                            break;
                        default:
                            Console.WriteLine();
                            Console.WriteLine("Please choose amoung these choices only");
                            flag = true;
                            break;
                    }
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("Please choose amoung these choices only");
                    flag = true;
                }
            }
            switch (typeOfDuck)
            {
                case Types.Rubber:
                    obj = new RubberDuck();
                    break;
                case Types.Mallard:
                    obj = new MallardDuck();
                    break;
                case Types.Redhead:
                    obj = new RedheadDuck();
                    break;
                default:
                    break;
            }
            Console.WriteLine();

            obj.CreateDuck();
            obj.ShowDetails();
        }

    }
}
