﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NumberGame
{
    class ValueNotInRangeException : Exception
    {
        static readonly string defaultMessage = "The value provided is not in Specified Range";

        public string ReturnPoint { get; set; }

        public ValueNotInRangeException()
            : base(defaultMessage)
        {

        }

        public ValueNotInRangeException(string message)
            : base(message)
        {

        }

        public ValueNotInRangeException( Exception innerException)
            : base(defaultMessage , innerException)
        {
                
        }

        public ValueNotInRangeException(string message,Exception innerException)
            : base(message,innerException)
        {

        }

        public ValueNotInRangeException(string message,string returnPoint)
        {
            ReturnPoint = returnPoint;
        }
    }
}
