﻿using System;
using static System.Console;
using static NumberGame.CheckNumberEntered;


namespace NumberGame
{
    class GameController
    {
        private int countTurns=0;
        private int firstInput;
     

        public void StartGame()
        {
            WriteLine("\n\t\t----Starting Game----\n");
            countTurns += 1;
            WriteLine("Enter a number between 1 and 5");
            int value;

            try
            {
                value = ValidateIntInput(ReadLine());
                firstInput = value;
                bool valid = CheckRange(value);
                if (valid)
                {
                    ContinueGame();
                }
            }
            catch (ValueNotInRangeException ex)
            {
                Console.WriteLine("\nException encountered:\t " + ex.Message);
                StartGame();
            }
        }

        public void ContinueGame()
        {
            int value = firstInput;
            Console.WriteLine();
            switch (value)
            {
                case 1:
                    WriteLine("Enter a even number : ");
                    break;
                case 2:
                    WriteLine("Enter a odd number : ");
                    break;
                case 3:
                    WriteLine("Enter a prime number : ");
                    break;
                case 4:
                    WriteLine("Enter a negative number : ");
                    break;
                case 5:
                    WriteLine("Enter Zero : ");
                    break;
            }
            int numberEntered = 0;
            try
            {
                 numberEntered = ValidateIntInput(ReadLine());
                switch (value)
                {
                    case 1:
                        CheckEven(numberEntered);
                        break;
                    case 2:
                        CheckOdd(numberEntered);
                        break;
                    case 3:
                        CheckPrime(numberEntered);
                        break;
                    case 4:
                        CheckNegative(numberEntered);
                        break;
                    case 5:
                        CheckZero(numberEntered);
                        break;
                }

                if (CheckStoppingCondition())
                {
                    StartGame();
                }
                else
                {
                    StopGame();
                }
            }

            catch (ValueNotInRangeException ex)
            {
                Console.WriteLine();
                WriteLine("Error in input : " + ex.Message);
                ContinueGame();
            }
            catch (ValueNotCorrectException ex)
            {
                Console.WriteLine();
                Console.WriteLine("Exception encountered:\t " + ex.Message);
                StartGame();
            }
        }

        public bool CheckStoppingCondition()
        {
            if(countTurns < 5)
            {
                return true;
            }
            return false;
        }

        public void StopGame()
        {
            WriteLine("\n\t\t----Stopping----\t\t\n");
            WriteLine("Reached Maximum Number Of tries.");
        }



        public bool CheckRange(int value)
        {
            if(value >=1 && value <= 5)
            {
                return true;
            }
            throw new ValueNotInRangeException();
        }

        public int ValidateIntInput(string value)
        {
            int temp;
            if (int.TryParse(value, out temp))
            {
                return temp;
            }
            else
            {
                throw new ValueNotInRangeException("Entered Value should be Integer");
            }
            
        }

        public double ValidateDoubleInput(string value)
        {
            double temp;
            if (double.TryParse(value, out temp))
            {
                return temp;
            }
            else
            {
                throw new ValueNotInRangeException("Entered Value should be double");
            }
            
        }
    }
}
