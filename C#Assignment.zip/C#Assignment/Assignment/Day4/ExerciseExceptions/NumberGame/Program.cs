﻿using System;

namespace NumberGame
{
    class Program
    {
        static void Main(string[] args)
        {
            GameController obj = new GameController();
            try
            {
                
                obj.StartGame();
            }

            catch(Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine("Exception encountered:\t " + ex.Message);
            }
        } 
    }
}
