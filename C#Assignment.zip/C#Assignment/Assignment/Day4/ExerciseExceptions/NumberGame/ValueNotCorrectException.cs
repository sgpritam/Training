﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NumberGame
{
    class ValueNotCorrectException : Exception
    {
        public ValueNotCorrectException(string message)
            : base(message)
        {

        }
    }
}
