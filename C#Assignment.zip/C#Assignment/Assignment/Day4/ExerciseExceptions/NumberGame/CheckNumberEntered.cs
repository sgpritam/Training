﻿using System;


namespace NumberGame
{
    class CheckNumberEntered
    {
        public static void CheckEven(double value)
        {
            if(value % 2 == 0)
            {
                Console.WriteLine("Success");
            }
            else
            {
                throw new ValueNotCorrectException("Value entered is not a Even Number");
            }
        }

        public static void CheckOdd(double value)
        {
            if (value % 2 != 0)
            {
                Console.WriteLine("Success");
            }
            else
            {
                throw new ValueNotCorrectException("Value entered is not a odd Number");
            }
        }

        public static void CheckPrime(double value)
        {
            if(value <= 1) 
            {
                throw new ValueNotCorrectException("Value entered is not a prime Number");
            }
            else
            {
                for(int i = 2; i < value/2; i++)
                {
                    if(value % i == 0)
                    {
                        //throw 
                        return;
                    }
                }
                Console.WriteLine("Success");
            }
        }

        public static void CheckNegative(double value)
        {
            if (value < 0)
            {
                Console.WriteLine("Success");
            }
            else 
            {
                throw new ValueNotCorrectException("Value entered is not a Negative Number");
            }
        }

        public static void CheckZero(double value)
        {
            if (value == 0)
            {
                Console.WriteLine("Success");
            }
            else  
            {
                throw new ValueNotCorrectException("Value entered is not a Zero");
            }
        }
    }
}
