﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FileInOutExercise
{
    class Initilizers
    {
        // Use your own path to continue ...... 
        public const string Start = @"D:\C#Assignment\Assignment\Day4"; 
    }
}
