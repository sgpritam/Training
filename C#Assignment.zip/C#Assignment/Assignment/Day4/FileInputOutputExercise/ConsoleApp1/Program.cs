﻿using System;

namespace FileInOutExercise

{
    class Program
    {
        static void Main(string[] args)
        {
            // Firstly go to Initiliers Class and Change start Value according to your Directory Path

            SizeOfFiles file = new SizeOfFiles();
            FileExtensions files = new FileExtensions();

            Console.WriteLine("\n----\t\tLongest Files\t\t----\n");
            file.showLongestFile();

            Console.WriteLine("\n----\t\t5 Longest Files\t\t----\n");
            file.ShowFiveLargest();

            Console.WriteLine("----\t\tNo of Text Files\t\t----\n");
            files.CountTextFiles();

            Console.WriteLine("\n----\t\tExtensions\t\t----\n");
            files.ShowExtension();

            Console.ReadKey();
        }
    }
}
