﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;


namespace FileInOutExercise
{
    class FileExtensions
    {
        static DirectoryInfo dir = new DirectoryInfo(Initilizers.Start);
        IEnumerable<FileInfo> fileList = dir.GetFiles("*.*", SearchOption.AllDirectories);

        public void ShowExtension()
        {
            var extensionCounts = dir.EnumerateFiles("*.*", SearchOption.AllDirectories).GroupBy(x => x.Extension).Select(g => new { Extension = g.Key, Count = g.Count() }).ToList();

            foreach (var group in extensionCounts)
            {
                Console.WriteLine("There are -----{0}----- files with extension------- {1}", group.Count, group.Extension);
            }
        }

        public void CountTextFiles()
        {

            var fileCount = (from file in Directory.EnumerateFiles(Initilizers.Start, "*.txt", SearchOption.AllDirectories)
                             select file).Count();

            Console.WriteLine("There are total ----{0}---- files of type extension txt ", fileCount);

        }
    }
}
