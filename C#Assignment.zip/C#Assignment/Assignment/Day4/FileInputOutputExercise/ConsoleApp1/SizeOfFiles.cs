﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace FileInOutExercise
{
    class SizeOfFiles
    {
        static DirectoryInfo dir = new DirectoryInfo(Initilizers.Start);
        static IEnumerable<FileInfo> fileList = dir.GetFiles("*.*", SearchOption.AllDirectories);

        public void ShowFiveLargest()
        {
            var queryFiveLargest =
              (from file in fileList
               let len = GetFileLength(file)
               orderby len descending
               select file).Take(5);
            Console.WriteLine("The 10 largest files under {0} are:", Initilizers.Start);

            foreach (var v in queryFiveLargest)
            {
                Console.WriteLine("{0}: -----{1}------ bytes", v.FullName, v.Length);
            }
        }



        public void showLongestFile()
        {
            FileInfo longestFile =
                        (from file in fileList
                         let len = GetFileLength(file)
                         where len > 0
                         orderby len descending
                         select file)
                          .First();
            Console.WriteLine("The largest file under {0} --------is--------- {1} with a length of ------{2}----- bytes", Initilizers.Start, longestFile.FullName, longestFile.Length);
        }

        private static long GetFileLength(FileInfo fi)
        {
            long retval;
            try
            {
                retval = fi.Length;
            }
            catch (FileNotFoundException)
            {
                retval = 0;
            }
            return retval;
        }
    }
}
