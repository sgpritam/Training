﻿using System;
using System.Collections.Generic;
using static LambdaAndDelegates.LambdaAndDelegateMethods;
namespace LambdaAndDelegates
{
    class Program
    {
        public static void PrintListItems(List<int> values)
        {
            foreach (int value in values)
            {
                Console.Write($"{value} ");
            }
            Console.WriteLine();
        }
        static void Main(string[] args)
        {
            PrintListItems(new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 });

            PrintListItems(OddNumbersUsingLambda());

            PrintListItems(EvenNumbersUsingLambda());

            PrintListItems(PrimeNumbersUsingAnonymousDel());

            PrintListItems(PrimeNumbersUsingLambda());

            PrintListItems(GreaterThan5UsingGroupMethod());

            PrintListItems(LessThan5UsingDelegateMethodConv());

            PrintListItems(Find3K());

            PrintListItems(Find3KOne());

            PrintListItems(Find3KTwo());

            PrintListItems(FindAnyThingUsingAnonymous());

            PrintListItems(FindAnythingUsingMethodGroup());

        }
    }
}
