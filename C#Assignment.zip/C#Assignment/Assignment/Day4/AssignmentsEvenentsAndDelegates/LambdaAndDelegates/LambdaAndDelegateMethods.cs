﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LambdaAndDelegates
{
    
    public static class LambdaAndDelegateMethods
    {
        static List<int> intList = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

        public static List<int> OddNumbersUsingLambda()
        {
            List<int> oddIntegers = intList.Where(num => num % 2 == 1).ToList();
            Console.WriteLine("All odd numbers in list using Lambda without curly brackets:");
            return oddIntegers;
        }

        public static List<int> EvenNumbersUsingLambda()
        {
            List<int> evenIntegers = intList.Where(num => { return num % 2 == 0; }).ToList();
            Console.WriteLine("All even numbers in list using Lambda with curly brackets:");
            return evenIntegers;
        }

        public static List<int> PrimeNumbersUsingAnonymousDel()
        {
            List<int> primeNumbers = intList.Where(delegate (int number)
            {
                if (number < 2)
                    return false;
                if (number == 2)
                    return true;
                for(int i = 2; i < number/2; i++)
                {
                    if(number % i == 0)
                    {
                        return false;
                    }
                }
                return true;
            }).ToList();
            Console.WriteLine("All Primes Numbers in List using Anonymous Delegates:");
            return primeNumbers;
        }

        public static List<int> PrimeNumbersUsingLambda()
        {
            List<int> primeNumbers = intList.Where(number => {
                if (number < 2)
                    return false;
                if (number == 2)
                    return true;   
                for (int i = 2; i < number / 2; i++)
                {
                    if (number % i == 0)
                    {
                        return false;
                    }
                }
                return true;
            }).ToList();
            Console.WriteLine("All Primes Numbers in List using Lambdas:");
            return primeNumbers;
        }

        public static List<int> GreaterThan5UsingGroupMethod()
        {
            List<int> numbers = intList.Where(GreaterThanFive).ToList();
            Console.WriteLine("Integers Greater Than Five using Method Group Conversion Syntax:");
            return numbers ;
        }

        private static bool GreaterThanFive(int x)
        {
            return x > 5;
        }

        public static List<int> LessThan5UsingDelegateMethodConv()
        {
            Func<int, bool> lessThanFiveDelegate = new Func<int, bool>(LessThanFive);
            List<int> lessThanFive = intList.Where(lessThanFiveDelegate).ToList();
            Console.WriteLine("Elements Less Than Five – Delegate Object in Where – Method Group Conversion Syntax in Constructor of Object:");
            return lessThanFive;
        }
        private static bool LessThanFive(int x)
        {
            return x < 5;
        }

        public static List<int> Find3K()
        {
            Func<int, bool> threeKDelegate = new Func<int, bool>(num => { return num % 3 == 0; });
            List<int> threeK = intList.Where(threeKDelegate).ToList();
            Console.WriteLine("Find 3k – Delegate Object in Where – Lambda Expression in Constructor of Object:");
            return threeK;
        }

        public static List<int> Find3KOne()
        {
            Func<int, bool> threeKPlusOneDelegate = new Func<int, bool>(delegate (int num) { return num % 3 == 1; });
            List<int> threeKPlusOne = intList.Where(threeKPlusOneDelegate).ToList();
            Console.WriteLine("Find 3k + 1 - Delegate Object in Where – Anonymous Method in Constructor of Object:");
            return threeKPlusOne;
        }

        public static List<int> Find3KTwo()
        {
            Func<int, bool> threeKPlusTwoDelegate = num => num % 3 == 2;
            List<int> threeKPlusTwo = intList.Where(threeKPlusTwoDelegate).ToList();
            Console.WriteLine("Find 3k + 2 - Delegate Object in Where –Lambda Expression:");
            return threeKPlusTwo;
        }

        public static List<int> FindAnyThingUsingAnonymous()
        {
            Func<int, bool> findAnythingAnonymousDelegate = delegate (int num) { return num % 5 == 3; };
            List<int> findAnythingAnonymous = intList.Where(findAnythingAnonymousDelegate).ToList();
            Console.WriteLine("Find anything (5K + 3) - Delegate Object in Where – Anonymous Method:");
            return findAnythingAnonymous;
        }

        public static List<int> FindAnythingUsingMethodGroup()
        {
            Func<int, bool> findAnythingGroupDelegate = Helper;
            List<int> findAnythingGroup = intList.Where(findAnythingGroupDelegate).ToList();
            Console.WriteLine("Find anything (5K + 3) - Delegate Object in Where – Method Group Conversion:");
            return findAnythingGroup;
        }
        private static bool Helper(int x)
        {
            return x % 5 == 3;
        }

    }
}
