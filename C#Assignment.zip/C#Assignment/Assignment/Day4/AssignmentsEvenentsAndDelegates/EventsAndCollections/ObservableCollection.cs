﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EventsAndCollections
{
    public enum NotifyCollectionChangedAction { Addition, Removal };

    class ObservableCollection
    {

        public event EventHandler<IntEventArgs> ChangedActionEvent;

        List<int> observableList ;
        

        public ObservableCollection()
        {
            observableList = new List<int>();
        }
        
        public void AddToCollection(int x)
        {
            observableList.Add(x);
            IntEventArgs value = new IntEventArgs();
            value.Value = x;
            value.actionType = NotifyCollectionChangedAction.Addition;
            OnChangedAction(value);
        }

        public void RemoveFromCollection(int x)
        {
            if (observableList.Contains(x))
            {
                observableList.Remove(x);
                IntEventArgs value = new IntEventArgs();
                value.Value = x;
                value.actionType = NotifyCollectionChangedAction.Removal;
                OnChangedAction(value);
            }
            else
            {
                Console.WriteLine("Element not found in the collection");
            }
        }

        public void OnChangedAction(IntEventArgs value)
        {
            ChangedActionEvent?.Invoke(this,value);
        }
    }
}
