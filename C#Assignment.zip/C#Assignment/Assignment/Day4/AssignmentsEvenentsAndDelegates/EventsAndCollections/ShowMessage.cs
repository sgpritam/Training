﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EventsAndCollections
{
    class ShowMessage
    { 
        public void ShowMessageOnAction(object source , IntEventArgs value)
        {
            if(value.actionType == NotifyCollectionChangedAction.Addition)
            {
                Console.WriteLine($"1.	Addition: “Element {value.Value} is added in collection”");
            }
            else
            {
                Console.WriteLine($"1.	Removal: “Element {value.Value} is removed from the collection”");
            }
        }
    }
}
