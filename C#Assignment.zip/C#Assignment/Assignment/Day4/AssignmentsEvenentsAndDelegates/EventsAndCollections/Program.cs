﻿using System;

namespace EventsAndCollections
{
    class Program
    {
        static void Main(string[] args)
        {
            ObservableCollection collection = new ObservableCollection();
            ShowMessage showMessage = new ShowMessage();
            collection.ChangedActionEvent += showMessage.ShowMessageOnAction;

            collection.AddToCollection(1);
            collection.RemoveFromCollection(1);
        }
    }
}
