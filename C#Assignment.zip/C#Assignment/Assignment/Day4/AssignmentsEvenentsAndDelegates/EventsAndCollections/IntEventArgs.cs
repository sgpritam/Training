﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EventsAndCollections
{
    class IntEventArgs : EventArgs
    {
        public int Value { get; set; }
        public NotifyCollectionChangedAction actionType = new NotifyCollectionChangedAction();
    }
}
