﻿using System;

namespace EventsAssignment
{
    class Program
    {
        static void Main(string[] args)
        {
            ProductInventory productInventory = new ProductInventory();
            productInventory.PriceChangedEvent += productInventory.UpdateInventoryPrice;
            productInventory.FoundDefectiveProduct += productInventory.RemoveProduct;

            productInventory.AddProduct(new Product(1, 30));
            productInventory.AddProduct(new Product(2, 40));
            productInventory.AddProduct(new Product(3, 50));
            productInventory.AddProduct(new Product(4, 100));
            productInventory.AddProduct(new Product(5, 50));
            productInventory.AddProduct(new Product(5, 50));
            productInventory.ShowTotalValue();
            productInventory.ChangePriceOfProduct(new Product(5, 50) , 100);
            productInventory.PrintInventory();
            productInventory.ShowTotalValue();
            productInventory.ChangeDefectivenessOfProduct(new Product(4, 100));
            productInventory.PrintInventory();
            productInventory.ShowTotalValue();
        }
    }
}
