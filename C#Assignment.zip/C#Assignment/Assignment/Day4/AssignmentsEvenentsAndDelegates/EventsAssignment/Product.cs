﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EventsAssignment
{
    class Product : EventArgs , IEquatable<Product>
    {
        public int id;
        public double price;
        public bool isDefective;

        public Product()
        {
            isDefective = false;
        }

        public Product(int _id , double _price)
        {
            id = _id;
            price = _price;
            isDefective = false;
        }

        public bool Equals(Product obj)
        {
            if (this.id == obj.id && (this.price == obj.price))
            {
                return true;
            }
            return false;
        }
    }
}
