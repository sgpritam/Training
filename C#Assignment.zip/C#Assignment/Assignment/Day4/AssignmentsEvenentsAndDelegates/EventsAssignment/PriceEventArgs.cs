﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EventsAssignment
{
    class PriceEventArgs : EventArgs
    {
        internal double ChangedPrice { get; set; }
        internal double ActualPrice { get; set; }
    }
}
