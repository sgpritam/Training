﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EventsAssignment
{
    
    class ProductInventory 
    {
        public event EventHandler<PriceEventArgs> PriceChangedEvent;
        public event EventHandler<Product> FoundDefectiveProduct;

        Dictionary<Product, int> inventory = new Dictionary<Product, int>();
        double totalValue = 0;

        public void PrintInventory()
        {
            if(inventory.Count == 0)
            {
                Console.WriteLine("No Product Found :(");
                return;
            }
            foreach(Product product in inventory.Keys)
            {
                Console.WriteLine($"ID : {product.id}\t Price : Rs.{product.price}\t Quantity : {inventory[product]}");
            }
        }

        public void ShowTotalValue()
        {
            Console.WriteLine("Total Inventory value : " + totalValue);
        }

        public void AddProduct(Product product)
        {
            bool flag = false;
            foreach(Product p in inventory.Keys)
            {
                if (p.Equals(product))
                {
                    product = p;
                    flag = true;
                    break;
                }
            }

            if (flag)
            {
                inventory[product]++;
                totalValue += product.price;
            }
            else
            {
                inventory.Add(product, 1);
                totalValue += product.price;
            }
        }

        public void RemoveProduct(object source ,Product product)
        {
            bool flag = false;
            foreach (Product p in inventory.Keys)
            {
                if (p.Equals(product))
                {
                    product = p;
                    flag = true;
                    break;
                }
            }
            if (flag)
            {
                inventory.Remove(product);

            }
            else
            {
                Console.Write("No such product exists.");
            }
        }

        public void ChangePriceOfProduct(Product product, int value)
        {
            bool flag = false;
            foreach (Product p in inventory.Keys)
            {
                if (p.Equals(product))
                {
                    product = p;
                    flag = true;
                    break;
                }
            }
            if (!flag)
            {
                Console.WriteLine("Please enter product first");
            }
            else
            {
                foreach(Product obj in inventory.Keys)
                {
                    if (obj.Equals(product))
                    {
                        double temp = obj.price;
                        obj.price = value;
                        OnPriceChange(new PriceEventArgs { ChangedPrice = value*inventory[obj] , ActualPrice = temp });
                    }
                }
            }
        }

        private void OnPriceChange(PriceEventArgs p)
        {
            PriceChangedEvent?.Invoke(this,p);
        }

        public void UpdateInventoryPrice(object source , PriceEventArgs value)
        {
            totalValue = totalValue - value.ActualPrice + value.ChangedPrice;
        }

        public void ChangeDefectivenessOfProduct(Product product)
        {
            
            
            foreach (Product p in inventory.Keys)
            {
                if (p.Equals(product))
                {
                    p.isDefective = true;
                    Console.WriteLine("Defective Found!");
                    OnDefectiveProductFound(p); 
                    break;
                }
            } 
        }

        private void OnDefectiveProductFound(Product product)
        {
            FoundDefectiveProduct(this, product);
        }


    }

    
}
