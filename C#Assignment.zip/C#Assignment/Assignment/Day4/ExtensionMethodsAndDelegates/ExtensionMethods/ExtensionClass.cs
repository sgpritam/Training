﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExtensionMethods
{
    public static class  ExtensionClassForInt
    {
        public static bool IsOdd(this Int32 x)
        {
            return x % 2 != 0;
        }

        public static bool IsEven(this Int32 x)
        {
            return x % 2 == 0;
        }

        public static bool IsPrime(this Int32 x)
        {
            if(x>=0 && x < 2)
            {
                return false;
            }
            if(x == 2)
            {
                return true;
            }
            for(int i = 2; i< x/2; i++)
            {
                if (x % i == 0)
                {
                    return false;
                }
            }
            return true;
        }

        public static bool IsDivisibleBy(this Int32 x, int y)
        {
            if(y != 0)
            {
                return x % y == 0;
            }
            return false;
        }
    }
}
