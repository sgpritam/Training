﻿using System;

namespace ExtensionMethods
{
    class Program
    {
        static void Main(string[] args)
        {
            int val1 = 2;
            Console.WriteLine(val1.IsEven());

            int val2 = 3;
            Console.WriteLine(val2.IsOdd());

            int val3 = 2;
            Console.WriteLine(val3.IsPrime());

            int val4 = 10;
            Console.WriteLine(val4.IsDivisibleBy(5));
        }
    }
}
