﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ExtensionMethodsOnIEnummerable
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> listOfIntegers = new List<int>();
            Console.Write( "List : " );
            for(int i = 1; i <= 10; i++)
            {
                listOfIntegers.Add(i);
                Console.Write(i + " ");
            }
            Console.WriteLine();
            
            // Using CustomAll Extension method.   
            Console.WriteLine("All number greater than 0 : " + listOfIntegers.CustomAll<int>(x => x >= 0));

            // Using CustomAny Extension method.  
            Console.WriteLine("Any number equal t0 0 : " + listOfIntegers.CustomAny<int>(x => x == 0));

            // Using CustomMax Extension method
            Console.WriteLine("Max number amoung all  : " + listOfIntegers.CustomMax<int>());

            // Using CustomMin Extension method
            Console.WriteLine("Min number amoung all  : " + listOfIntegers.CustomMin<int>());

            // Using CustomWhere Extension method
            Console.WriteLine("Even Numbers using CustomWhere");
            var evenNumbers = listOfIntegers.CustomWhere<int>(x => x % 2 == 0).ToList();
            foreach(var item in evenNumbers)
            {
                Console.Write(item + " ");
            }
            Console.WriteLine();

            

        }
    }
}
