﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace ExtensionMethodsOnIEnummerable
{
    public delegate bool CustomAllDelegate();

    public static class CustomExtensionMethods
    {
        public static bool CustomAll<T>(this IEnumerable<T> source, Func<T, bool> predicate)
        {
            foreach(T element in source)
            {
                if (!predicate(element))
                {
                    return false;
                }
            }
            return true;
        }

        public static bool CustomAny<T>(this IEnumerable<T> source, Func<T, bool> predicate)
        {
            foreach (T element in source)
            {
                if (predicate(element))
                {
                    return true;
                }
            }
            return false;
        }

        public static T CustomMax<T>(this IEnumerable<T> source)
        {
            return source.Max<T>();
        }

        public static T CustomMin<T>(this IEnumerable<T> source)
        {
            return source.Min<T>();
        }

        public static IEnumerable<T> CustomWhere<T>(this IEnumerable<T> source, Func<T, bool> predicate)
        {
            return source.Where(predicate);
        }

       
    }
}
