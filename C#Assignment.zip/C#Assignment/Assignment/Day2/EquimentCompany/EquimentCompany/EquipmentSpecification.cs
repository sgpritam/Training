﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EquimentCompany
{
    public class EquipmentSpecification : EquipmentInventory
    {
        string _name;
        string Name
        {
            get
            {
                return _name;
            }
            set
            {
                if (!String.IsNullOrEmpty(value))
                {
                    _name = value;
                }
                else
                {
                    string temp = null;
                    while (String.IsNullOrEmpty(temp))
                    {
                        Console.WriteLine("Enter the appropriate Name Of Equiment");
                        temp = Console.ReadLine();
                    }
                    _name = temp;
                }
            }
        }
        string description;
        double distanceMoved = 0;
        double maintenanceCost = 0;




        public override void CreateEquipment()
        {
            Console.WriteLine("\n\n----\tCreate New Equipment\t----");
            Console.Write("Enter the name of equipment\n");
            Name = Console.ReadLine();
            Console.WriteLine("Enter Description of Equipment");
            description = Console.ReadLine();


        }

        public virtual double CalcMaintenanceCost(double distance)
        {
            return 0;
        }

        public override void MoveBy(double distance)
        {
            distanceMoved += distance;
            maintenanceCost = CalcMaintenanceCost(distanceMoved);
        }

        public override void ShowEquipment()
        {
            Console.WriteLine("\n----\tDetails Of Equipment\t----\n");
            Console.WriteLine("Name of Equipment\t: " + Name);
            Console.WriteLine("Description\t\t : " + description);
            Console.WriteLine("Distance Travelled\t : " + distanceMoved);
            Console.WriteLine("Maintenance Cost\t : " + maintenanceCost);
            Console.WriteLine("Type of Equipment\t : " + typeOfEquipment);

        }
    }
}

