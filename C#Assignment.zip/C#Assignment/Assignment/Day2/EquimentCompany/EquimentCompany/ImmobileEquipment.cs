﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EquimentCompany
{
    class ImmobileEquipment : EquipmentSpecification
    {
        double weight;

        public ImmobileEquipment()
        {
            typeOfEquipment = Types.Immobile;
        }
        public override void CreateEquipment()
        {
            base.CreateEquipment();
            Console.WriteLine("Enter Weight of Equipment : ");
            while (!double.TryParse(Console.ReadLine(), out weight))
            {
                Console.WriteLine("\nPlease enter a integer value for No of Wheels");
            }
        }
        public override void ShowEquipment()
        {
            base.ShowEquipment();
            Console.WriteLine("Weight of Equipment\t : " + weight);
        }
        public override double CalcMaintenanceCost(double distance)
        {
            return distance * weight;
        }
    }
}
