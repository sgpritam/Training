﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EquimentCompany
{
    public abstract class EquipmentInventory
    {
        public enum Types
        {
            Mobile,
            Immobile
        };
        public Types typeOfEquipment;
        public abstract void CreateEquipment();
        public abstract void ShowEquipment();
        public abstract void MoveBy(double distance);
    }
}

