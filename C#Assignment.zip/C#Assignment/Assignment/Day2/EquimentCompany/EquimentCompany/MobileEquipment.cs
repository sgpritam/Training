﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EquimentCompany
{
    public class MobileEquipment : EquipmentSpecification
    {
        int noOfTyres = 0;

        public MobileEquipment()
        {
            typeOfEquipment = Types.Mobile;
        }

        public override void CreateEquipment()
        {
            base.CreateEquipment();
            Console.WriteLine("Enter No of Wheels");
            while (!int.TryParse(Console.ReadLine(), out noOfTyres))
            {
                Console.WriteLine("\nPlease enter a integer value for No of Wheels");
            }
        }
        public override void ShowEquipment()
        {
            base.ShowEquipment();
            Console.WriteLine("Number of Wheels\t : " + noOfTyres);
        }
        public override double CalcMaintenanceCost(double distance)
        {
            return distance * noOfTyres;
        }

    }
}

