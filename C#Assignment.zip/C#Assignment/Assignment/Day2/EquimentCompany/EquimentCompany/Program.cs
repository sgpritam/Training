﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EquimentCompany
{
    class Program
    {
        enum Types { Mobile, Immobile, Nothing };

        static void Main(string[] args)
        {
            EquipmentInventory obj;
             

            Types typeOfEquipment = Types.Nothing;
            Console.WriteLine("\t\tSelect Type of Equipment");
            bool flag = false;
            while (!flag)
            {
                Console.WriteLine($"\nPlease select 1 or 2 \n1 - {(Types)0}\t2-{(Types)1}");
                char temp = Console.ReadKey().KeyChar;
                string temp2 = Convert.ToString(temp);
                int temp3;
                if (int.TryParse(temp2, out temp3))
                {
                    switch (temp3)
                    {
                        case 1:
                            typeOfEquipment = (Types)0;

                            flag = true;
                            break;
                        case 2:
                            flag = true;
                            typeOfEquipment = (Types)1;

                            break;
                        default:
                            flag = false;
                            Console.WriteLine();
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("\nPlease Enter Appropriate Input");
                    flag = false;
                }
            }

            if (typeOfEquipment == (Types)0)
            {
                obj = new MobileEquipment();
            }
            else
            {
                obj = new ImmobileEquipment();
            }

            obj.CreateEquipment();
            obj.ShowEquipment();


            while (true)
            {
                Console.WriteLine("\nEnter the distance to be travelled");
                double distance;
                while (!double.TryParse(Console.ReadLine(), out distance))
                {
                    Console.WriteLine("Enter the appropriate double value ");
                }
                obj.MoveBy(distance);
                obj.ShowEquipment();
                Console.WriteLine("Press q to quit or any another key to continue");
                char temp = Console.ReadKey().KeyChar;
                string quit = Convert.ToString(temp);
                if (quit == "q")
                {
                    break;
                }
            }
        }
    }
}