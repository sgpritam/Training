﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DuckStimulationGame
{

    public interface IDucks<T>
    {
        T DuckType { get; set; }
        void CreateDuck();
        void ShowDetails();
    }
}
