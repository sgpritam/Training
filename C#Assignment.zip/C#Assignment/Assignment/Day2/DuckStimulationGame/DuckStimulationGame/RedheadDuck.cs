﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DuckStimulationGame
{
    class RedheadDuck : DuckStimulator, IDucks<Types>
    {
        public RedheadDuck()
        {
            DuckType = Types.Redhead;
            canFly = true;
            duckQuack = "Mild";
        }

        public override void ShowDetails()
        {
            base.ShowDetails();
            Console.WriteLine("Can Fly ? : " + canFly);
            Console.WriteLine("Quack : " + duckQuack);
        }
    }
}
