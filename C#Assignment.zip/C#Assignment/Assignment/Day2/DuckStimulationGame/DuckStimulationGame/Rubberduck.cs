﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DuckStimulationGame
{
    class RubberDuck : DuckStimulator, IDucks<Types>
    {
        public RubberDuck()
        {
            DuckType = Types.Rubber;
            canFly = false;
            duckQuack = "Squeak";
        }

        public override void ShowDetails()
        {
            base.ShowDetails();
            Console.WriteLine("Can Fly ? : " + canFly);
            Console.WriteLine("Quack : " + duckQuack);
        }
    }
}
