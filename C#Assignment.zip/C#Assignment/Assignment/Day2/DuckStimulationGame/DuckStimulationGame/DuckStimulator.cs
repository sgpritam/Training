﻿using System;

namespace DuckStimulationGame

{
    enum Types { Rubber, Mallard, Redhead, Nothing }
    class DuckStimulator : IDucks<Types>
    {

        protected bool canFly;
        protected string duckQuack;

        private int noOfWings;


        protected double weight;

        private Types DuckStimulatorTypes;
        public Types DuckType
        {
            get
            {
                return DuckStimulatorTypes;
            }
            set
            {
                DuckStimulatorTypes = value;
            }
        }

        public void CreateDuck()
        {
            Console.WriteLine("\n\t\t----Create New Duck----\t\t\n");
            Console.WriteLine("Enter Number of Wings for Duck");
            while (!int.TryParse(Console.ReadLine(), out noOfWings))
            {
                Console.WriteLine("Enter a integer value");
            }
            Console.WriteLine("Enter Weight for Duck");
            while (!double.TryParse(Console.ReadLine(), out weight))
            {
                Console.WriteLine("Enter a double value for weight ");
            }
        }

        public virtual void ShowDetails()
        {
            Console.WriteLine("----\tDetails Of Duck\t----\n");
            Console.WriteLine("Type : " + DuckType);
            Console.WriteLine("Weight : " + weight);
            Console.WriteLine("Wings : " + noOfWings);

        }
    }
}
