﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DuckStimulationGame
{
    class MallardDuck : DuckStimulator, IDucks<Types>
    {
        public MallardDuck()
        {
            DuckType = Types.Mallard;
            canFly = true;
            duckQuack = "Loud";
        }

        public override void ShowDetails()
        {
            base.ShowDetails();
            Console.WriteLine("Can Fly ? : " + canFly);
            Console.WriteLine("Quack : " + duckQuack);
        }
    }
}
