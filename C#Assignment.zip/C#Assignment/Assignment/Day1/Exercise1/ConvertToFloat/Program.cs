﻿using System;

namespace ConvertToFloat
{
    class Conversion
    {
        // Conversion by float.Parse
        public static void ByFloatParse(string value)
        {
            float result = float.Parse(value);
            Console.WriteLine($"float.Parse result : \t{result}");
        }

        // Conversion by float.TryParse
        public static void ByFloatTryParse(string value)
        {
            float result;
            bool valid = float.TryParse(value, out result);
            if (valid)
            {
                Console.WriteLine($"float.TryParse result : {result}");
            }
            else
            {
                Console.WriteLine("Unable To Convert to Float");
                Console.ReadKey();
            }
        }

        // Conversion by Convert.ToDouble
        public static void ByConvertToDouble(string value)
        {
            double result = Convert.ToDouble(value);
            Console.WriteLine($"Convert.ToDouble result : {result}");
        }
    }

    // Driver Class

    class Program
    {
        // Driver Main Function
        static void Main(string[] args)
        {
            Console.WriteLine("\t\tConvert Input Value To Float");
            Console.WriteLine("\nEnter the value ... ");
            string value = Console.ReadLine();

            Conversion.ByFloatTryParse(value);

            Conversion.ByFloatParse(value);

            Conversion.ByConvertToDouble(value);

            Console.ReadKey();

        }
    }
}
