﻿using System;

namespace ConvertToBool
{
    class Conversion
    {
        // Conversion by bool.Parse
        public static void ByBoolParse(string value)
        {
            bool result = bool.Parse(value);
            Console.WriteLine($"bool.Parse result : \t{result}");
        }

        // Conversion by bool.TryParse
        public static void ByBoolTryParse(string value)
        {
            bool result;
            bool valid = bool.TryParse(value, out result);
            if (valid)
            {
                Console.WriteLine($"bool.TryParse result : \t{result}");
            }
            else
            {
                Console.WriteLine("Unable To Convert to Bool");
                Console.ReadKey();
            }
        }

        // Conversion by Convert.ToBoolean
        public static void ByConvertToBoolean(string value)
        {
            bool result = Convert.ToBoolean(value);
            Console.WriteLine($"Convert.ToBoolean result : {result}");
        }
    }

    // Driver Class

    class Program
    {
        // Driver Main Function
        static void Main(string[] args)
        {
            Console.WriteLine("\t\tConvert Input Value To Bool");
            Console.WriteLine("\nEnter the value ... ");
            string value = Console.ReadLine();

            Conversion.ByBoolTryParse(value);

            Conversion.ByBoolParse(value);

            Conversion.ByConvertToBoolean(value);

            Console.ReadKey();

        }
    }
}
