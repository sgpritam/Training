﻿using System;

namespace ConvertToInteger
{
    class Conversion
    {
        // Conversion by int.Parse
        public static void ByIntParse(string value)
        {
            int result = int.Parse(value);
            Console.WriteLine($"int.Parse result : \t{result}");
        }

        // Conversion by int.TryParse
        public static void ByIntTryParse(string value)
        {
            int result;
            bool valid = int.TryParse(value, out result);
            if (valid)
            {
                Console.WriteLine($"int.TryParse result : \t{result}");
            }
            else
            {
                Console.WriteLine("Unable To Convert to Integer");
                Console.ReadKey();
            }
        }

        // Conversion by Convert.ToInt32
        public static void ByConvertToInt32(string value)
        {
            int result = Convert.ToInt32(value);
            Console.WriteLine($"Convert.ToInt32 result : {result}");
        }
    }

    // Driver Class

    class Program
    {
        // Driver Main Function
        static void Main(string[] args)
        {
            Console.WriteLine("\t\tConvert Input Value To Integer");
            Console.WriteLine("\nEnter the value ... ");
            string value = Console.ReadLine();

            Conversion.ByIntTryParse(value);

            Conversion.ByIntParse(value);
            
            Conversion.ByConvertToInt32(value);

            Console.ReadKey();

        }
    }
}
