﻿using System;

namespace Exercise2
{
    class Program
    {
        static void Main(string[] args)
        {
            Person person1 = new Person();
            person1.Firstname = "Pritam";
            person1.Lastname = "Kumar";
            person1.Birthdate = new DateTime(1998, 10, 15);

            Person person2 = new Person();
            person2.Firstname = "Pritam";
            person2.Lastname = "Kumar";
            person2.Birthdate = new DateTime(1998, 10, 15);



            bool isSame = person1.Equals(person2);
            Console.WriteLine(isSame);

            Console.ReadKey();

            bool isSameObject = person1.ReferenceEquals(person2); // false

            Person person3 = person1;
            bool isSameObject2 = person1.ReferenceEquals(person3); // true
        }
    }
}
