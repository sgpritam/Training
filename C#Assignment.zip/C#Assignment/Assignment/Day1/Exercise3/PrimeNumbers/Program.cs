﻿using System;

namespace PrimeNumbers
{
    class Program
    {
        public static bool CheckPrime(int num)
        {
            int i;
            bool flag = true;
            for(i = 2; i <= num/2; i++)
            {
                if(num%i == 0)
                {
                    flag = false;
                    break;
                }
            }
            if (flag)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static void PrintPrimeNumbers(int num1 ,int num2)
        {
            for(int i = num1; i <= num2; i++)
            {
                if (CheckPrime(i))
                {
                    Console.WriteLine(i);
                }
            }
        }

        static void Main(string[] args)
        {
            Console.WriteLine("\t\t\t Find Prime Numbers Between 2 numbers\n");
            int num1, num2;
            while (true)
            {
                Console.WriteLine("\nEnter 1st Integer Between 2 and 1000 and press enter");
                bool valid1 = int.TryParse(Console.ReadLine(),out num1);
                if (!valid1)
                {
                    Console.WriteLine("Invalid input");
                    continue;
                }
                else
                {
                    if(!(num1>2 && num1 < 1000))
                    {
                        Console.WriteLine("Interger Should be btw 2 and 1000");
                        continue;
                    }
                }
                Console.WriteLine("Enter 2nd Integer Between 2 and 1000 and press enter");
                bool valid2 = int.TryParse(Console.ReadLine(), out num2);
                if (!valid2)
                {
                    Console.WriteLine("Invalid input");
                    continue;
                }
                else
                {
                    if (!(num2 > 2 && num2 < 1000))
                    {
                        Console.WriteLine("Interger Should be btw 2 and 1000");
                        continue;
                    }
                    else
                    {
                        if (num1 >= num2)
                        {
                            Console.WriteLine("1st integer should be smaller than 2nd Integer");
                        }
                        else
                        {
                            break;
                        }
                    }
                }

            }
            
            PrintPrimeNumbers(num1, num2);
            Console.ReadKey();
        }
    }
}
