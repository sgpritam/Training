﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EquipmentInventory
{

    public class EquipmentSpecification : EquipmentInventory
    {


        public override void CreateEquipment()
        {

            Console.WriteLine("\nEnter the name of equipment");
            Name = Console.ReadLine();
            Console.WriteLine("Enter Description of Equipment");
            description = Console.ReadLine();


        }

        public virtual double CalcMaintenanceCost(double distance)
        {
            return 0;
        }

        public override void MoveBy(double distance)
        {
            distanceMoved += distance;
            maintenanceCost = CalcMaintenanceCost(distanceMoved);
        }

        public override void ShowEquipment()
        {
            Console.WriteLine("\n----\tDetails Of Equipment\t----\n");
            Console.WriteLine("Name of Equipment\t: " + Name);
            Console.WriteLine("Description\t\t : " + description);
            Console.WriteLine("Distance Travelled\t : " + distanceMoved + "km");
            Console.WriteLine("Maintenance Cost\t : Rs." + maintenanceCost);
            Console.WriteLine("Type of Equipment\t : " + typeOfEquipment);

        }
    }
}
