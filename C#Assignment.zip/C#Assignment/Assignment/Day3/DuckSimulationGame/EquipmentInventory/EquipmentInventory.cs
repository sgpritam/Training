﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EquipmentInventory
{
    public enum Types { Mobile, Immobile, Nothing };
    public abstract class EquipmentInventory
    {

        public Types typeOfEquipment;
        string _name;
        internal string Name
        {
            get
            {
                return _name;
            }
            set
            {
                if (!String.IsNullOrEmpty(value))
                {
                    _name = value;
                }
                else
                {
                    string temp = null;
                    while (String.IsNullOrEmpty(temp))
                    {
                        Console.WriteLine("Enter the appropriate Name Of Equiment");
                        temp = Console.ReadLine();
                    }
                    _name = temp;
                }
            }
        }
        internal string description;
        internal double distanceMoved = 0;
        internal double maintenanceCost = 0;
        public abstract void CreateEquipment();
        public abstract void ShowEquipment();
        public abstract void MoveBy(double distance);
    }
}
