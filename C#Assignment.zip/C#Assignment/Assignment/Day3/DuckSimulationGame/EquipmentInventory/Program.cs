﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace EquipmentInventory
{
    class Program
    {

        public static void Main(string[] args)
        {
            EquipmentList obj = new EquipmentList();
            Console.WriteLine("------\t\tEquipment Inventory\t\t------\n");

            bool flag = true;
            while (flag)
            {
                Console.WriteLine("\nPlease Choose one of the following options to continue or press any other key to Exit :-");

                Console.WriteLine("1. Create New Equipment");
                Console.WriteLine("2. Delete an Equipment");
                Console.WriteLine("3. Move an Equipment");
                Console.WriteLine("4. List all Equipments");
                Console.WriteLine("5. Details of an Equipment");
                Console.WriteLine("6. List all Moblie Equipments");
                Console.WriteLine("7. List all Immobile Equipments");
                Console.WriteLine("8. List Equipments that have not moved till now");
                Console.WriteLine("9. Delete all Equipments");
                Console.WriteLine("10. Delete all Mobile Equipments");
                Console.WriteLine("11. Delete all Immobile Equipments");

                var value = Console.ReadLine();
                switch (value)
                {
                    case "1":
                        obj.AddEquipment();
                        break;
                    case "2":
                        obj.DeleteEquipment();
                        break;
                    case "3":
                        obj.MoveAnEquipment();
                        break;
                    case "4":
                        obj.ListAllEquipments();
                        break;
                    case "5":
                        obj.ShowDetailsOfEquipment();
                        break;
                    case "6":
                        obj.ListAllMobileEquipments();
                        break;
                    case "7":
                        obj.ListAllImmobileEquipments();
                        break;
                    case "8":
                        obj.ShowUnMovedEquipments();
                        break;
                    case "9":
                        obj.DeleteAllEquipments();
                        break;
                    case "10":
                        obj.DeleteAllMobileEquipments();
                        break;
                    case "11":
                        obj.DeleteAllImmobileEquipments();
                        break;
                    default:
                        flag = false;
                        break;
                }
            }

        }


    }
}
