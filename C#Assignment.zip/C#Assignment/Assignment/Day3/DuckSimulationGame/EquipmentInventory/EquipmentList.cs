﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EquipmentInventory
{
    class EquipmentList
    {

        List<EquipmentInventory> listOfEquipments = new List<EquipmentInventory>();

        public void AddEquipment()
        {
            EquipmentSpecification obj;
            Types typeOfEquipment = Types.Nothing;
            Console.WriteLine("----\t\tCreate New Equipment\t\t----\n");
            Console.WriteLine("\t\tSelect Type of Equipment");
            bool flag = false;
            while (!flag)
            {
                Console.WriteLine($"\nPlease select 1 or 2 \n1 - {(Types)0}\t2-{(Types)1}");
                char temp = Console.ReadKey().KeyChar;
                string temp2 = Convert.ToString(temp);
                int temp3;
                if (int.TryParse(temp2, out temp3))
                {
                    switch (temp3)
                    {
                        case 1:
                            typeOfEquipment = (Types)0;

                            flag = true;
                            break;
                        case 2:
                            flag = true;
                            typeOfEquipment = (Types)1;

                            break;
                        default:
                            flag = false;
                            Console.WriteLine();
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("\nPlease Enter Appropriate Input");
                    flag = false;
                }

            }

            if (typeOfEquipment == (Types)0)
            {
                obj = new MobileEquipment();
            }
            else
            {
                obj = new ImmobileEquipment();
            }
            obj.CreateEquipment();
            listOfEquipments.Add(obj);
        }

        public void ListAllEquipments()
        {
            Console.WriteLine("\n\t\t----All Equipments----");
            if (listOfEquipments.Count != 0)
            {

                Action<EquipmentInventory> printAllEquipments = item =>
                {
                    Console.WriteLine($"Name : {item.Name}\tDescription : {item.description} ");
                };

                listOfEquipments.ForEach(printAllEquipments);
            }
            else
            {
                Console.WriteLine("No equipment Exists! Please add equipments first.");
            }
        }

        public void ShowDetailsOfEquipment()
        {
            if (listOfEquipments.Count == 0)
            {
                Console.WriteLine("No equipment in Inventory. ");
                return;
            }
            Console.WriteLine("\n\t\t----Details Of a Equipment----");
            Console.WriteLine("\nPlease enter the name of Equipment to see Details");
            var item = Console.ReadLine();
            var x = from i in listOfEquipments
                    where i.Name == item
                    select i;
            List<EquipmentInventory> equipment = x.ToList();
            if (equipment.Count != 0)
            {
                foreach (var i in equipment)
                {
                    i.ShowEquipment();
                }
            }
            else
            {
                Console.WriteLine("No such Equipment Exists.");
            }
        }

        public void DeleteEquipment()
        {
            if (listOfEquipments.Count == 0)
            {
                Console.WriteLine("No equipment in Inventory. ");
                return;
            }
            Console.WriteLine("\n\t\t----Deleted a Equipment----");
            Console.WriteLine("\nPlease enter the name of Equipment to be Deleted.");
            var item = Console.ReadLine();
            var x = from i in listOfEquipments
                    where i.Name == item
                    select i;
            List<EquipmentInventory> equipment = x.ToList();
            if (equipment.Count != 0)
            {
                foreach (var i in equipment)
                {
                    listOfEquipments.Remove(i);
                }
            }
            else
            {
                Console.WriteLine("No such Equipment Exists.");
            }
        }

        public void DeleteAllEquipments()
        {
            if (listOfEquipments.Count == 0)
            {
                Console.WriteLine("No equipment in Inventory. ");
                return;
            }
            listOfEquipments.Clear();
        }

        public void MoveAnEquipment()
        {
            if (listOfEquipments.Count == 0)
            {
                Console.WriteLine("No equipment in Inventory. ");
                return;
            }
            Console.WriteLine("\n\t\t----Move an Equipment----");
            Console.WriteLine("\nPlease enter the name of Equipment to Move");
            var item = Console.ReadLine();
            var x = from i in listOfEquipments
                    where i.Name == item
                    select i;
            List<EquipmentInventory> equipment = x.ToList();
            if (equipment.Count != 0)
            {
                Console.WriteLine("\nEnter the distance to be moved in km");
                double distance;
                while (!double.TryParse(Console.ReadLine(), out distance))
                {
                    Console.WriteLine("Please enter a integer value or double value");
                }
                foreach (var i in equipment)
                {

                    i.MoveBy(distance);
                }
                Console.WriteLine("Equipment moved successfuly.");
            }
            else
            {
                Console.WriteLine("No such Equipment Exists.");
            }
        }

        public void ListAllMobileEquipments()
        {
            if (listOfEquipments.Count == 0)
            {
                Console.WriteLine("No equipment in Inventory. ");
                return;
            }
            Console.WriteLine("\n\t\t----All Mobile Equipments----\n");
            var temp = from i in listOfEquipments
                       where i.typeOfEquipment.Equals((Types)0)
                       select i;
            List<EquipmentInventory> mobileEquip = temp.ToList();
            if (mobileEquip.Count != 0)
            {
                Action<EquipmentInventory> printAllEquipments = item =>
                {
                    Console.WriteLine($"Name : {item.Name}\tDescription : {item.description} ");
                };

                mobileEquip.ForEach(printAllEquipments);
            }
            else
            {
                Console.WriteLine("No such equipment exists.");
            }
        }

        public void ListAllImmobileEquipments()
        {
            if (listOfEquipments.Count == 0)
            {
                Console.WriteLine("No equipment in Inventory. ");
                return;
            }
            Console.WriteLine("\n\t\t----All Immobile Equipments----\n");
            var temp = from i in listOfEquipments
                       where i.typeOfEquipment.Equals((Types)1)
                       select i;
            List<EquipmentInventory> immobileEquip = temp.ToList();
            if (immobileEquip.Count != 0)
            {
                Action<EquipmentInventory> printAllEquipments = item =>
                {
                    Console.WriteLine($"Name : {item.Name}\tDescription : {item.description} ");
                };

                immobileEquip.ForEach(printAllEquipments);
            }
            else
            {
                Console.WriteLine("No such equipments");
            }
        }

        public void DeleteAllMobileEquipments()
        {
            if (listOfEquipments.Count == 0)
            {
                Console.WriteLine("No equipment in Inventory. ");
                return;
            }
            Console.WriteLine("\n\t\t----Delete All Mobile Equipments----\n");
            var temp = from i in listOfEquipments
                       where i.typeOfEquipment.Equals((Types)0)
                       select i;
            List<EquipmentInventory> mobileEquip = temp.ToList();
            if (mobileEquip.Count != 0)
            {
                Action<EquipmentInventory> printAllEquipments = item =>
                {
                    listOfEquipments.Remove(item);
                };

                mobileEquip.ForEach(printAllEquipments);
                Console.WriteLine("Deleted successfully.");
            }
            else
            {
                Console.WriteLine("No Mobile equipment exists! So can't perform this operation");
            }
        }

        public void DeleteAllImmobileEquipments()
        {
            if (listOfEquipments.Count == 0)
            {
                Console.WriteLine("No equipment in Inventory. ");
                return;
            }
            Console.WriteLine("\n\t\t----Delete Immobile equipments----\n");
            var temp = from i in listOfEquipments
                       where i.typeOfEquipment.Equals((Types)1)
                       select i;
            List<EquipmentInventory> immobileEquip = temp.ToList();
            if (immobileEquip.Count != 0)
            {
                Action<EquipmentInventory> printAllEquipments = item =>
                {
                    listOfEquipments.Remove(item);
                };

                immobileEquip.ForEach(printAllEquipments);
                Console.WriteLine("Deleted successfully.");
            }
            else
            {
                Console.WriteLine("No Immobile equipment exists! So can't perform this operation");
            }
        }

        public void ShowUnMovedEquipments()
        {
            if (listOfEquipments.Count == 0)
            {
                Console.WriteLine("No equipment in Inventory. ");
                return;
            }
            Console.WriteLine("\n\t\t----Equiments with 0 moved distance----\n");
            var temp = from i in listOfEquipments
                       where i.distanceMoved == 0
                       select i;
            List<EquipmentInventory> zeroDistance = temp.ToList();
            if (zeroDistance.Count != 0)
            {
                Action<EquipmentInventory> printAllEquipments = item =>
                {
                    Console.WriteLine($"Name : {item.Name}\tDescription : {item.description} ");
                };

                zeroDistance.ForEach(printAllEquipments);

            }
            else
            {
                Console.WriteLine("No such Equipment exists.");
            }
        }
    }
}
