﻿using System;

namespace DuckStimulationGame

{
    enum Types { Rubber, Mallard, Redhead, Nothing }

    class DuckStimulator : IDucks<Types>

    {
        internal string name;
        internal bool canFly;
        internal string duckQuack;

        internal int noOfWings;


        internal double weight;

        private Types _duckTypes;
        public Types DuckType
        {
            get
            {
                return _duckTypes;
            }
            set
            {
                _duckTypes = value;
            }
        }


        public void CreateDuck()
        {

            Console.WriteLine("\nEnter the name of Duck");
            string temp = Console.ReadLine();
            if (string.IsNullOrEmpty(temp))
            {
                Console.WriteLine("Please enter appropriate name of duck");
                CreateDuck();
            }
            else
            {
                name = temp;
                Console.WriteLine("Enter Number of Wings for Duck");
                while (!int.TryParse(Console.ReadLine(), out noOfWings))
                {
                    Console.WriteLine("Enter a integer value");
                }
                Console.WriteLine("Enter Weight for Duck");
                while (!double.TryParse(Console.ReadLine(), out weight))
                {
                    Console.WriteLine("Enter a double value for weight ");
                }
            }
        }

        public virtual void ShowDetails()
        {
            Console.WriteLine("----\tDetails Of Duck\t----\n");
            Console.WriteLine("Type : " + DuckType);
            Console.WriteLine("Weight : " + weight);
            Console.WriteLine("Wings : " + noOfWings);

        }
    }
}
