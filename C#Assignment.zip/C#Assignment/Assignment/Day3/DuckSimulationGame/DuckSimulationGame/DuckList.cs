﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DuckStimulationGame
{
    class DuckList
    {

        List<DuckStimulator> listofDucks;

        public DuckList()
        {
            listofDucks = new List<DuckStimulator>();
        }


        public void AddDuck()
        {
            Console.WriteLine("----\t\tWant To Create some Awesome Ducks ?\t\t----\n");
            Console.WriteLine("Please select the type of Duck you want to create ...");
            DuckStimulator obj = new DuckStimulator();
            Types typeOfDuck = Types.Nothing;
            bool flag = true;
            int opt;
            while (flag)
            {
                Console.WriteLine("Choose -\n1. Rubber\n2. Mallard\n3. Redhead ");
                var temp = Convert.ToString(Console.ReadKey().KeyChar);
                if (int.TryParse(temp, out opt))
                {
                    switch (opt)
                    {
                        case 1:
                            flag = false;
                            typeOfDuck = (Types)0;
                            break;
                        case 2:
                            flag = false;
                            typeOfDuck = (Types)1;
                            break;
                        case 3:
                            flag = false;
                            typeOfDuck = (Types)2;
                            break;
                        default:
                            Console.WriteLine();
                            Console.WriteLine("Please choose amoung these choices only");
                            flag = true;
                            break;
                    }
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("Please choose amoung these choices only");
                    flag = true;
                }
            }
            switch (typeOfDuck)
            {
                case Types.Rubber:
                    obj = new RubberDuck();
                    break;
                case Types.Mallard:
                    obj = new MallardDuck();
                    break;
                case Types.Redhead:
                    obj = new RedheadDuck();
                    break;
                default:
                    break;
            }
            obj.CreateDuck();
            listofDucks.Add(obj);
        }

        public void RemoveDuck()
        {
            Console.WriteLine("\n\t\t----Remove a duck! ----\n");
            if (listofDucks.Count == 0)
            {
                Console.WriteLine("No ducks present. Please add a duck first.");
                return;
            }
            Console.WriteLine("Enter the Name of duck you want to remove.");
            var duckName = Console.ReadLine().ToString();
            var temp = from i in listofDucks
                       where i.name == duckName
                       select i;
            List<DuckStimulator> duckToBeRemoved = temp.ToList();
            if (duckToBeRemoved.Count != 0)
            {
                foreach (var i in duckToBeRemoved)
                {
                    listofDucks.Remove(i);
                }
                Console.WriteLine("\nRemoved successfully");
            }
            else
            {
                Console.WriteLine("This duck doesnot exits.");
            }
        }

        public void RemoveAllDucks()
        {
            if (listofDucks.Count != 0)
            {
                listofDucks.Clear();
                Console.WriteLine("Ducks Removed succefully.");
            }
            else
            {
                Console.WriteLine("No Duck exists.");
            }
        }

        public void SortDuckList()
        {
            if (listofDucks.Count == 0)
            {
                Console.WriteLine("No ducks available");
                return;
            }

            var sortedList = (listofDucks.OrderBy(x => x.weight)).ToList();
            foreach (var duck in sortedList)
            {
                Console.WriteLine($"Name : {duck.name}\t" +
                    $"Type : {duck.DuckType}\t" +
                    $"Wings : {duck.noOfWings}\t" +
                    $"Weight : {duck.weight}" +
                    $"Quack : {duck.duckQuack}\t" +
                    $"Fly : {duck.canFly}");
            }
        }

        public void SortDuckListByWings()
        {
            if (listofDucks.Count == 0)
            {
                Console.WriteLine("No ducks available");
                return;
            }

            var sortedList = (listofDucks.OrderBy(x => x.noOfWings)).ToList();
            foreach (var duck in sortedList)
            {
                Console.WriteLine($"Name : {duck.name}\t" +
                    $"Type : {duck.DuckType}\t" +
                    $"Wings : {duck.noOfWings}\t" +
                    $"Weight : {duck.weight}" +
                    $"");
            }
        }

    }
}
