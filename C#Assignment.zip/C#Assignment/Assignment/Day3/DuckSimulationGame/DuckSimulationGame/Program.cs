﻿using System;

namespace DuckStimulationGame
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("----\t\tWelcome To Duck Stimulation Game\t\t----\n");

            DuckList duck = new DuckList();
            StartGame(duck);
        }

        static void StartGame(DuckList duck)
        {
            while (true)
            {
                Console.WriteLine("\nPlease Select from below options to continue or press other key to exit.");
                Console.WriteLine("1. Add Duck");
                Console.WriteLine("2. Remove Duck");
                Console.WriteLine("3. Remove all Ducks");
                Console.WriteLine("4. Sorted Duck List w.r.t. Weights");
                Console.WriteLine("5. Sorted Duck List w.r.t. Wings");

                var value = (Console.ReadKey().KeyChar).ToString();
                Console.WriteLine();
                switch (value)
                {
                    case "1":
                        duck.AddDuck();
                        break;
                    case "2":
                        duck.RemoveDuck();
                        break;
                    case "3":
                        duck.RemoveAllDucks();
                        break;
                    case "4":
                        duck.SortDuckList();
                        break;
                    case "5":
                        duck.SortDuckListByWings();
                        break;
                    default:
                        return;

                }
            }
        }
    }
}
