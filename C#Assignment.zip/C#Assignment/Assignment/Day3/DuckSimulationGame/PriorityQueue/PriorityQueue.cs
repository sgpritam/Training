﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriorityQueue
{
    class PriorityQueue<T> where T : IEquatable<T>  //IComapreable
    {
        private SortedDictionary<int, IList<T>> elements;  //
       
        public PriorityQueue()
        {
            elements = new SortedDictionary<int, IList<T>>();
            Count = 0;
        }

        public PriorityQueue(SortedDictionary<int, IList<T>> elements) : this()
        {

        }

        public int Count { get; private set; }


        public bool Contains(T item)
        {
            bool flag = false;
            if (Count <= 0)
            {
                //throw
            }
            foreach (var x in elements)
            {
                if (x.Value[0].Equals(item))
                {
                    flag = true;
                }
             //   return true;
            }


            if (flag)
            {
                return true;
            }
            else
            {
                return false;
            }

        }


        public void Enqueue(int priority, T item)
        {
            if (!Contains(item))
            {

                List<T> number = new List<T>();
                number.Add(item);
                elements.Add(priority, number);
                Count++;
            }
            else
            {
                // Item present
            }
        }

        public T Dequeue()
        {

            if (Count <= 0)
            {
                // throw

            }
            var HighestPriority = GetHighestPriority();
            var queue = elements[HighestPriority];
            elements.Remove(HighestPriority);
            return queue.FirstOrDefault();  //Returns the first element of a sequence,or a default value if no element is found.
        }


        public T Peek()
        {
            int maxPriority = GetHighestPriority();
            var queue = elements[maxPriority];

            return queue.FirstOrDefault();
        }
     

        private int GetHighestPriority()
        {

            var max = 0;
            foreach (var item in elements.Keys)
            {
                if (max < item)
                {
                    max = item;
                }
            }
            return max;
        }

        public void PrintPriorityQueue()
        {
            foreach (var i in elements.Reverse())
            {
                Console.WriteLine({i.Key} + {i.Value[0]});  //$" "--remove
            }
        }
    }
}

