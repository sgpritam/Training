﻿using System;

namespace PriorityQueue
{
    class Program
    {
        static void Main(string[] args)
        {
            PriorityQueue<string> priorityQueue = new PriorityQueue<string>();

            //Check Elements in Queue ---->
            Console.WriteLine($"No of Elements in Queue : {priorityQueue.Count}");

            // Enqueue operation ---->
            priorityQueue.Enqueue(4, "Thanos");
            priorityQueue.Enqueue(3, "Caption America");
            priorityQueue.Enqueue(2, "Caption Marvel");
            priorityQueue.Enqueue(5, "Iron Man");
            priorityQueue.Enqueue(6, "Thor");
            priorityQueue.Enqueue(1, "Hulk");

            //Printing Queue
            priorityQueue.PrintPriorityQueue();
            Console.WriteLine();

            //Check Elements in Queue ---->
            Console.WriteLine($"No of Elements in Queue : {priorityQueue.Count}");

            //Check Contains ??
            Console.WriteLine("Whether Queue Contains `Thanos` ? : " + priorityQueue.Contains("Thanos"));

            // Dequeue ---->

            priorityQueue.Dequeue();

            priorityQueue.PrintPriorityQueue();

            string element = priorityQueue.Peek();

            Console.WriteLine("Peek Element : " + element);
            Console.ReadKey();

        }
    }
}
